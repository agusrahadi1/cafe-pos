import { Injectable, BadRequestException } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class UploadsService {
  private readonly uploadRootDir = path.join(process.cwd(), 'uploads');
  private readonly allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
    'image/svg+xml',
  ];
  private readonly maxFileSizeBytes = 5 * 1024 * 1024; // 5MB

  constructor() {
    this.ensureDirectoryExists(this.uploadRootDir);
    this.ensureDirectoryExists(path.join(this.uploadRootDir, 'products'));
    this.ensureDirectoryExists(path.join(this.uploadRootDir, 'logos'));
  }

  private ensureDirectoryExists(dirPath: string) {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }

  async saveImage(file: Express.Multer.File, targetFolder: string = 'general') {
    if (!file) {
      throw new BadRequestException('File gambar tidak ditemukan');
    }

    if (!this.allowedMimeTypes.includes(file.mimetype)) {
      throw new BadRequestException(
        `Format file tidak didukung (${file.mimetype}). Hanya format JPG, PNG, WEBP, GIF, dan SVG yang diperbolehkan.`
      );
    }

    if (file.size > this.maxFileSizeBytes) {
      throw new BadRequestException('Ukuran file maksimal adalah 5MB');
    }

    // Sanitize folder name
    const safeFolder = ['products', 'logos'].includes(targetFolder) ? targetFolder : 'general';
    const targetDir = path.join(this.uploadRootDir, safeFolder);
    this.ensureDirectoryExists(targetDir);

    // Extract file extension
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    const filename = `${safeFolder}-${uuidv4()}${ext}`;
    const filePath = path.join(targetDir, filename);

    // Write file to disk
    await fs.promises.writeFile(filePath, file.buffer);

    const relativeUrl = `/uploads/${safeFolder}/${filename}`;

    return {
      message: 'File berhasil diunggah',
      url: relativeUrl,
      filename,
      originalName: file.originalname,
      size: file.size,
      mimetype: file.mimetype,
    };
  }
}

