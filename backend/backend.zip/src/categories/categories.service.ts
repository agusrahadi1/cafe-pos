import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { Category } from '@prisma/client';

@Injectable()
export class CategoriesService {
  constructor(private prisma: PrismaService) {}

  async create(createCategoryDto: CreateCategoryDto, outletId: string): Promise<Category> {
    const existingCategory = await this.prisma.category.findFirst({
      where: {
        outletId,
        name: createCategoryDto.name,
      },
    });

    if (existingCategory) {
      throw new ConflictException('Category name already exists in this outlet');
    }

    const maxSortOrder = await this.prisma.category.aggregate({
      where: { outletId },
      _max: { sortOrder: true },
    });

    return this.prisma.category.create({
      data: {
        ...createCategoryDto,
        outletId,
        sortOrder: (maxSortOrder._max.sortOrder || 0) + 1,
      },
    });
  }

  async findAll(outletId?: string): Promise<Category[]> {
    return this.prisma.category.findMany({
      where: outletId ? { outletId } : {},
      orderBy: { sortOrder: 'asc' },
      include: {
        _count: { select: { products: true } },
      },
    });
  }

  async findActive(outletId?: string): Promise<Category[]> {
    return this.prisma.category.findMany({
      where: {
        ...(outletId ? { outletId } : {}),
        isActive: true,
      },
      orderBy: { sortOrder: 'asc' },
      include: {
        products: {
          where: { isActive: true, status: 'AVAILABLE' },
          orderBy: { sortOrder: 'asc' },
        },
      },
    });
  }

  async findById(id: string, outletId: string): Promise<Category | null> {
    return this.prisma.category.findFirst({
      where: { id, outletId },
      include: {
        products: {
          where: { isActive: true },
          orderBy: { sortOrder: 'asc' },
        },
      },
    });
  }

  async update(id: string, outletId: string, updateCategoryDto: UpdateCategoryDto): Promise<Category> {
    const category = await this.findById(id, outletId);
    if (!category) {
      throw new NotFoundException('Category not found');
    }

    if (updateCategoryDto.name && updateCategoryDto.name !== category.name) {
      const existingCategory = await this.prisma.category.findFirst({
        where: {
          outletId,
          name: updateCategoryDto.name,
          NOT: { id },
        },
      });

      if (existingCategory) {
        throw new ConflictException('Category name already exists');
      }
    }

    return this.prisma.category.update({
      where: { id },
      data: updateCategoryDto,
    });
  }

  async remove(id: string, outletId: string): Promise<Category> {
    const category = await this.findById(id, outletId);
    if (!category) {
      throw new NotFoundException('Category not found');
    }

    const productsCount = await this.prisma.product.count({
      where: { categoryId: id },
    });

    if (productsCount > 0) {
      throw new ConflictException('Cannot delete category with existing products');
    }

    return this.prisma.category.delete({
      where: { id },
    });
  }

  async reorder(outletId: string, categoryIds: string[]): Promise<void> {
    for (let i = 0; i < categoryIds.length; i++) {
      await this.prisma.category.update({
        where: { id: categoryIds[i] },
        data: { sortOrder: i + 1 },
      });
    }
  }
}