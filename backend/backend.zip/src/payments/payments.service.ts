import { Injectable, NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Payment, PaymentStatus, PaymentMethod, OrderStatus, Prisma } from '@prisma/client';
import { ConfigService } from '@nestjs/config';
import { CoreApi, Snap } from 'midtrans-client';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class PaymentsService {
  private midtransCore: CoreApi;
  private midtransSnap: Snap;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    const serverKey = this.configService.get<string>('MIDTRANS_SERVER_KEY') || '';
    const clientKey = this.configService.get<string>('MIDTRANS_CLIENT_KEY') || '';
    const isProduction = this.configService.get<string>('MIDTRANS_IS_PRODUCTION') === 'true';

    this.midtransCore = new CoreApi({
      isProduction,
      serverKey,
      clientKey,
    });

    this.midtransSnap = new Snap({
      isProduction,
      serverKey,
      clientKey,
    });
  }

  async generatePaymentNumber(outletId: string): Promise<string> {
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');

    const lastPayment = await this.prisma.payment.findFirst({
      where: { outletId },
      orderBy: { createdAt: 'desc' },
      select: { paymentNumber: true },
    });

    let sequence = 1;
    if (lastPayment) {
      const lastSeq = parseInt(lastPayment.paymentNumber.slice(-4), 10);
      if (!isNaN(lastSeq)) {
        sequence = lastSeq + 1;
      }
    }

    return `PAY${dateStr}${sequence.toString().padStart(4, '0')}`;
  }

  async createPaymentForOrder(
    orderId: string,
    outletId: string,
    method: PaymentMethod,
    amount: Prisma.Decimal | number,
    idempotencyKey: string,
  ): Promise<Payment> {
    // Check idempotency
    const existingPayment = await this.prisma.payment.findFirst({
      where: { idempotencyKey },
    });

    if (existingPayment) {
      return existingPayment;
    }

    const paymentNumber = await this.generatePaymentNumber(outletId);

    const payment = await this.prisma.payment.create({
      data: {
        orderId,
        outletId,
        paymentNumber,
        method,
        amount: new Prisma.Decimal(amount),
        status: PaymentStatus.PENDING_PAYMENT,
        provider: method === PaymentMethod.MIDTRANS || method === PaymentMethod.QRIS ? 'midtrans' : 'manual',
        idempotencyKey,
      },
    });

    return payment;
  }

  async processMidtransPayment(paymentId: string): Promise<{ token: string; redirectUrl: string }> {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
      include: { order: { include: { items: true, outlet: true } } },
    });

    if (!payment) {
      throw new NotFoundException('Payment not found');
    }

    if (payment.status !== PaymentStatus.PENDING_PAYMENT) {
      throw new ConflictException('Payment already processed');
    }

    const order = payment.order;
    const itemDetails = order.items.map((item) => ({
      id: item.productId,
      price: Number(item.unitPrice),
      quantity: item.quantity,
      name: item.productName + (item.variantName ? ` - ${item.variantName}` : ''),
    }));

    const snapRequest = {
      transaction_details: {
        order_id: payment.paymentNumber,
        gross_amount: Number(payment.amount),
      },
      item_details: itemDetails,
      customer_details: {
        first_name: order.customerName || 'Customer',
        phone: order.customerPhone,
        email: order.customerPhone ? `${order.customerPhone}@cafe.local` : undefined,
      },
      enabled_payments: ['qris', 'gopay', 'shopeepay', 'bca_va', 'bni_va', 'bri_va', 'permata_va', 'other_va', 'alfamart', 'indomaret'],
      callbacks: {
        finish: `${this.configService.get('FRONTEND_URL')}/payment/finish`,
        error: `${this.configService.get('FRONTEND_URL')}/payment/error`,
        pending: `${this.configService.get('FRONTEND_URL')}/payment/pending`,
      },
    };

    const snapResponse = await this.midtransSnap.createTransaction(snapRequest);

    await this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        providerReference: payment.paymentNumber,
        providerPayload: snapResponse as any,
        status: PaymentStatus.PROCESSING,
      },
    });

    return {
      token: snapResponse.token,
      redirectUrl: snapResponse.redirect_url,
    };
  }

  async processQrisPayment(paymentId: string): Promise<{ qrString: string; qrImageUrl: string }> {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
      include: { order: { include: { items: true, outlet: true } } },
    });

    if (!payment) {
      throw new NotFoundException('Payment not found');
    }

    if (payment.status !== PaymentStatus.PENDING_PAYMENT) {
      throw new ConflictException('Payment already processed');
    }

    const order = payment.order;
    const itemDetails = order.items.map((item) => ({
      id: item.productId,
      price: Number(item.unitPrice),
      quantity: item.quantity,
      name: item.productName + (item.variantName ? ` - ${item.variantName}` : ''),
    }));

    const coreRequest = {
      payment_type: 'qris',
      transaction_details: {
        order_id: payment.paymentNumber,
        gross_amount: Number(payment.amount),
      },
      item_details: itemDetails,
      customer_details: {
        first_name: order.customerName || 'Customer',
        phone: order.customerPhone,
      },
    };

    const coreResponse = await this.midtransCore.charge(coreRequest);

    await this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        providerReference: coreResponse.transaction_id,
        providerPayload: coreResponse as any,
        status: PaymentStatus.PROCESSING,
      },
    });

    return {
      qrString: coreResponse.qr_string,
      qrImageUrl: coreResponse.qr_image_url || `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(coreResponse.qr_string)}&size=200x200`,
    };
  }

  async handleMidtransNotification(notification: any): Promise<Payment> {
    const { order_id, transaction_status, fraud_status, transaction_id, payment_type, gross_amount } = notification;

    if (order_id && typeof order_id === 'string' && order_id.startsWith('SUB-')) {
      const isPaid =
        (transaction_status === 'capture' && fraud_status === 'accept') ||
        transaction_status === 'settlement';

      if (isPaid) {
        const parts = order_id.split('-');
        const tenantSlug = parts[1];
        const company = await this.prisma.company.findFirst({
          where: { slug: { startsWith: tenantSlug } },
          include: {
            subscriptions: {
              where: { status: 'ACTIVE' },
              orderBy: { createdAt: 'desc' },
              take: 1,
              include: { plan: true },
            },
          },
        });

        if (company) {
          const now = new Date();
          let baseDate = now;
          const activeSub = company.subscriptions[0];
          if (activeSub && new Date(activeSub.endDate) > now) {
            baseDate = new Date(activeSub.endDate);
          }
          const endDate = new Date(baseDate);
          endDate.setMonth(endDate.getMonth() + 1);

          await this.prisma.tenantSubscription.updateMany({
            where: { tenantId: company.id, status: 'ACTIVE' },
            data: { status: 'EXPIRED' },
          });

          const planId = activeSub?.planId || (await this.prisma.subscriptionPlan.findFirst())?.id;
          if (planId) {
            await this.prisma.tenantSubscription.create({
              data: {
                tenantId: company.id,
                planId,
                startDate: now,
                endDate,
                status: 'ACTIVE',
                autoRenew: true,
                notes: `Webhook Midtrans settlement (${order_id})`,
              },
            });

            await this.prisma.company.update({
              where: { id: company.id },
              data: { status: 'ACTIVE' },
            });
          }
        }
      }

      return { status: 'SUCCESS', order_id, transaction_status } as any;
    }

    const payment = await this.prisma.payment.findFirst({
      where: { paymentNumber: order_id },
      include: { order: true },
    });

    if (!payment) {
      throw new NotFoundException('Payment not found');
    }

    // Idempotency check
    if (payment.status === PaymentStatus.PAID) {
      return payment;
    }

    let newStatus: PaymentStatus;
    let orderStatus: OrderStatus | null = null;

    switch (transaction_status) {
      case 'capture':
        if (payment_type === 'credit_card') {
          newStatus = fraud_status === 'challenge' ? PaymentStatus.PROCESSING : PaymentStatus.PAID;
          if (newStatus === PaymentStatus.PAID) orderStatus = OrderStatus.PAID;
        } else {
          newStatus = PaymentStatus.PAID;
          orderStatus = OrderStatus.PAID;
        }
        break;
      case 'settlement':
        newStatus = PaymentStatus.PAID;
        orderStatus = OrderStatus.PAID;
        break;
      case 'pending':
        newStatus = PaymentStatus.PENDING_PAYMENT;
        break;
      case 'deny':
        newStatus = PaymentStatus.FAILED;
        orderStatus = OrderStatus.PAYMENT_FAILED;
        break;
      case 'expire':
        newStatus = PaymentStatus.EXPIRED;
        orderStatus = OrderStatus.EXPIRED;
        break;
      case 'cancel':
        newStatus = PaymentStatus.FAILED;
        orderStatus = OrderStatus.PAYMENT_FAILED;
        break;
      default:
        newStatus = PaymentStatus.FAILED;
        orderStatus = OrderStatus.PAYMENT_FAILED;
    }

    return this.prisma.$transaction(async (tx) => {
      const updatedPayment = await tx.payment.update({
        where: { id: payment.id },
        data: {
          status: newStatus,
          providerReference: transaction_id,
          providerPayload: notification as any,
          paidAt: newStatus === PaymentStatus.PAID ? new Date() : null,
          failedAt: (newStatus === PaymentStatus.FAILED || newStatus === PaymentStatus.EXPIRED) ? new Date() : null,
          failureReason: (newStatus === PaymentStatus.FAILED || newStatus === PaymentStatus.EXPIRED) ? transaction_status : null,
        },
      });

      // Update order status if needed
      if (orderStatus && payment.orderId) {
        await tx.order.update({
          where: { id: payment.orderId },
          data: { status: orderStatus },
        });

        await tx.orderStatusHistory.create({
          data: {
            orderId: payment.orderId,
            fromStatus: payment.order.status,
            toStatus: orderStatus,
            reason: `Payment ${transaction_status}`,
            metadata: { paymentId: payment.id, transactionId: transaction_id } as any,
          },
        });
      }

      return updatedPayment;
    });
  }

  async handleMidtransRedirect(query: any): Promise<{ success: boolean; message: string; orderId?: string }> {
    const { order_id, transaction_status, transaction_id } = query;

    const payment = await this.prisma.payment.findFirst({
      where: { paymentNumber: order_id },
      include: { order: true },
    });

    if (!payment) {
      return { success: false, message: 'Payment not found' };
    }

    // Redirect is NOT source of truth - webhook is
    return {
      success: transaction_status === 'settlement' || transaction_status === 'capture',
      message: `Payment ${transaction_status}. Please wait for confirmation.`,
      orderId: payment.orderId,
    };
  }

  async findById(id: string, outletId: string): Promise<(Payment & { order?: any }) | null> {
    return this.prisma.payment.findFirst({
      where: { id, outletId },
      include: { order: true },
    });
  }

  async findByOrderId(orderId: string, outletId: string): Promise<Payment[]> {
    return this.prisma.payment.findMany({
      where: { orderId, outletId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findAll(outletId: string, filters?: any): Promise<Payment[]> {
    const where: any = { outletId };

    if (filters?.status) where.status = filters.status;
    if (filters?.method) where.method = filters.method;
    if (filters?.dateFrom || filters?.dateTo) {
      where.createdAt = {};
      if (filters?.dateFrom) where.createdAt.gte = new Date(filters.dateFrom);
      if (filters?.dateTo) where.createdAt.lte = new Date(filters.dateTo);
    }

    return this.prisma.payment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: { order: { select: { id: true, orderNumber: true, table: true } } },
    });
  }

  async refund(paymentId: string, outletId: string, amount?: Prisma.Decimal | number, reason?: string, userId?: string): Promise<Payment> {
    const payment = await this.findById(paymentId, outletId);
    if (!payment) {
      throw new NotFoundException('Payment not found');
    }

    if (payment.status !== PaymentStatus.PAID) {
      throw new ConflictException('Can only refund paid payments');
    }

    const decimalAmount = amount !== undefined ? new Prisma.Decimal(amount) : undefined;
    const refundAmount = decimalAmount || payment.amount;
    if (refundAmount.gt(payment.amount)) {
      throw new BadRequestException('Refund amount cannot exceed payment amount');
    }

    // For Midtrans, we would call their refund API here
    // For now, just update the payment record
    return this.prisma.$transaction(async (tx) => {
      const updatedPayment = await tx.payment.update({
        where: { id: paymentId },
        data: {
          status: refundAmount.eq(payment.amount) ? PaymentStatus.REFUNDED : PaymentStatus.PAID,
          refundedAt: new Date(),
          refundReason: reason,
          refundAmount: refundAmount.add(payment.refundAmount),
        },
      });

      if (payment.orderId) {
        await tx.order.update({
          where: { id: payment.orderId },
          data: { status: OrderStatus.REFUNDED },
        });

        await tx.orderStatusHistory.create({
          data: {
            orderId: payment.orderId,
            fromStatus: payment.order?.status || OrderStatus.PAID,
            toStatus: OrderStatus.REFUNDED,
            changedById: userId,
            reason: `Refund: ${reason}`,
            metadata: { paymentId, refundAmount: refundAmount.toString() } as any,
          },
        });
      }

      return updatedPayment;
    });
  }

  async getPaymentSummary(outletId: string, dateFrom?: Date, dateTo?: Date) {
    const where: any = { outletId };
    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = dateFrom;
      if (dateTo) where.createdAt.lte = dateTo;
    }

    const [byMethod, byStatus, totalAmount] = await Promise.all([
      this.prisma.payment.groupBy({
        by: ['method'],
        where: { ...where, status: PaymentStatus.PAID },
        _sum: { amount: true },
        _count: { id: true },
      }),
      this.prisma.payment.groupBy({
        by: ['status'],
        where,
        _sum: { amount: true },
        _count: { id: true },
      }),
      this.prisma.payment.aggregate({
        where: { ...where, status: PaymentStatus.PAID },
        _sum: { amount: true },
      }),
    ]);

    return {
      byMethod: byMethod.map((m) => ({
        method: m.method,
        count: m._count.id,
        total: m._sum.amount,
      })),
      byStatus: byStatus.map((s) => ({
        status: s.status,
        count: s._count.id,
        total: s._sum.amount,
      })),
      totalRevenue: totalAmount._sum.amount || new Prisma.Decimal(0),
    };
  }
}