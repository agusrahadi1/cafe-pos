import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Public } from '../auth/decorators/public.decorator';
import { UserRole } from '@prisma/client';
import { ProductStatus } from '@prisma/client';

@ApiTags('Products')
@Controller('products')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  @Post()
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiOperation({ summary: 'Create a new product' })
  async create(@Request() req: any, @Body() createProductDto: CreateProductDto) {
    return this.productsService.create(createProductDto, req.user.outletId);
  }

  @Public()
  @Get()
  @ApiOperation({ summary: 'Get all products' })
  @ApiQuery({ name: 'includeInactive', required: false, type: Boolean })
  async findAll(@Request() req: any, @Query('includeInactive') includeInactive?: boolean) {
    return this.productsService.findAll(req.user?.outletId, includeInactive);
  }

  @Public()
  @Get('active')
  @ApiOperation({ summary: 'Get active products (public for customers)' })
  async findActive(@Request() req: any) {
    return this.productsService.findActive(req.user?.outletId);
  }

  @Public()
  @Get('category/:categoryId')
  @ApiOperation({ summary: 'Get products by category' })
  async findByCategory(@Request() req: any, @Param('categoryId') categoryId: string) {
    return this.productsService.findByCategory(req.user?.outletId, categoryId);
  }

  @Public()
  @Get(':id')
  @ApiOperation({ summary: 'Get product by ID' })
  async findOne(@Request() req: any, @Param('id') id: string) {
    return this.productsService.findById(id, req.user?.outletId);
  }

  @Put(':id')
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiOperation({ summary: 'Update product' })
  async update(
    @Request() req: any,
    @Param('id') id: string,
    @Body() updateProductDto: UpdateProductDto,
  ) {
    return this.productsService.update(id, req.user.outletId, updateProductDto);
  }

  @Delete(':id')
  @Roles(UserRole.ADMIN)
  @ApiOperation({ summary: 'Delete product' })
  async remove(@Request() req: any, @Param('id') id: string) {
    return this.productsService.remove(id, req.user.outletId);
  }

  @Put(':id/status')
  @Roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)
  @ApiOperation({ summary: 'Update product status' })
  async updateStatus(
    @Request() req: any,
    @Param('id') id: string,
    @Body('status') status: ProductStatus,
  ) {
    return this.productsService.updateStatus(id, req.user.outletId, status);
  }

  @Put('reorder')
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiOperation({ summary: 'Reorder products' })
  async reorder(@Request() req: any, @Body('productIds') productIds: string[]) {
    return this.productsService.reorder(req.user.outletId, productIds);
  }
}