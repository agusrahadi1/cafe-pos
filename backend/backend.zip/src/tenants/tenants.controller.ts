import {
  Controller,
  Get,
  Post,
  Put,
  Param,
  Body,
  UseGuards,
  Request,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { TenantsService } from './tenants.service';
import { UpdateTenantProfileDto } from './dto/update-tenant-profile.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Public } from '../auth/decorators/public.decorator';
import { UserRole } from '@prisma/client';

@ApiTags('Tenants')
@Controller('tenants')
export class TenantsController {
  constructor(private readonly tenantsService: TenantsService) {}

  @Public()
  @Get('resolve/:slug')
  @ApiOperation({ summary: 'Publicly resolve tenant info, branding, and status by slug' })
  async resolveSlug(@Param('slug') slug: string) {
    return this.tenantsService.resolveSlug(slug);
  }

  @Get('profile')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get current tenant profile and quota usage' })
  async getProfile(@Request() req: any) {
    return this.tenantsService.getProfile(req.user.companyId);
  }

  @Put('profile')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update current tenant cafe profile and branding' })
  async updateProfile(@Request() req: any, @Body() dto: UpdateTenantProfileDto) {
    return this.tenantsService.updateProfile(req.user.companyId, dto);
  }

  @Post('subscription/checkout')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create Midtrans Snap transaction for subscription renewal or upgrade' })
  async createSubscriptionCheckout(@Request() req: any, @Body() dto: any) {
    return this.tenantsService.createSubscriptionCheckout(req.user.companyId, req.user, dto);
  }

  @Post('subscription/confirm')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.OWNER)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Confirm subscription payment and activate plan' })
  async confirmSubscriptionPayment(@Request() req: any, @Body() dto: any) {
    return this.tenantsService.confirmSubscriptionPayment(req.user.companyId, dto);
  }
}

