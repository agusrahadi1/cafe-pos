import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { UsersService } from '../../users/users.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(
    private configService: ConfigService,
    private usersService: UsersService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.get<string>('JWT_SECRET') || 'default-jwt-secret-key-cafe-pos-2026',
    });
  }

  async validate(payload: any) {
    const user = await this.usersService.findById(payload.sub);
    if (!user || user.status !== 'ACTIVE') {
      throw new UnauthorizedException('User not found or inactive');
    }

    if (user.role !== 'SUPERADMIN' && user.company) {
      if (user.company.status !== 'ACTIVE') {
        throw new UnauthorizedException(
          user.company.status === 'SUSPENDED'
            ? 'Akses kafe Anda saat ini ditangguhkan (SUSPENDED). Silakan hubungi Superadmin.'
            : 'Masa langganan kafe Anda telah kedaluwarsa. Silakan hubungi Superadmin.'
        );
      }
    }

    return {
      id: user.id,
      sub: user.id,
      email: user.email,
      role: user.role,
      companyId: user.companyId,
      outletId: user.outletId,
      fullName: user.fullName,
    };
  }
}