'use client';

import React, { useEffect, useState } from 'react';
import StaffNavbar from '@/components/layout/StaffNavbar';
import { api } from '@/lib/api';
import { Order, OrderStatus, Shift } from '@/types';
import { formatRupiah, formatTime } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import {
  RotateCw,
  Plus,
  Clock,
  CheckCircle2,
  UtensilsCrossed,
  ConciergeBell,
  CheckCheck,
  XCircle,
  Eye,
  X,
  Search,
  AlertCircle,
  Loader2,
  Printer,
  Coins,
  Banknote,
  ShieldAlert,
  AlertTriangle,
  Volume2,
  VolumeX,
  Bell,
} from 'lucide-react';
import { playNotificationSound, isAudioMuted, setAudioMuted, testAudioNotification } from '@/lib/audio';

export default function PosPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [receiptOrder, setReceiptOrder] = useState<Order | null>(null);
  const [tenantProfile, setTenantProfile] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Audio Notification & Waiter Call States
  const [audioMuted, setAudioMutedState] = useState(false);
  const [waiterCalls, setWaiterCalls] = useState<any[]>([]);
  const prevOrderIdsRef = React.useRef<Set<string>>(new Set());
  const prevWaiterCallIdsRef = React.useRef<Set<string>>(new Set());
  const isInitialLoadRef = React.useRef(true);

  useEffect(() => {
    setAudioMutedState(isAudioMuted());
  }, []);

  const toggleMute = () => {
    const next = !audioMuted;
    setAudioMutedState(next);
    setAudioMuted(next);
    if (!next) {
      testAudioNotification('order');
    }
  };

  // Shift States
  const [currentShift, setCurrentShift] = useState<Shift | null>(null);
  const [shiftChecking, setShiftChecking] = useState(true);
  const [isOpenShiftModalOpen, setIsOpenShiftModalOpen] = useState(false);
  const [isCloseShiftModalOpen, setIsCloseShiftModalOpen] = useState(false);
  const [openShiftName, setOpenShiftName] = useState('Shift Pagi');
  const [openInitialCash, setOpenInitialCash] = useState<number | string>(100000);
  const [closeActualCash, setCloseActualCash] = useState<number | string>('');
  const [closeNotes, setCloseNotes] = useState('');
  const [shiftSubmitting, setShiftSubmitting] = useState(false);
  const [shiftError, setShiftError] = useState('');
  const [shiftSummary, setShiftSummary] = useState<any>(null);

  // Protect route
  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const fetchOrders = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    try {
      const res = await api.get<Order[]>('/orders');
      if (res && Array.isArray(res)) {
        if (!isInitialLoadRef.current) {
          const newOrders = res.filter((o) => !prevOrderIdsRef.current.has(o.id));
          if (newOrders.length > 0) {
            playNotificationSound('order');
          }
        } else {
          isInitialLoadRef.current = false;
        }

        prevOrderIdsRef.current = new Set(res.map((o) => o.id));
        setOrders(res);
      }
    } catch (e) {
      console.error('Error fetching orders:', e);
    } finally {
      setLoading(false);
      if (isManual) setRefreshing(false);
    }
  };

  const fetchWaiterCalls = async () => {
    try {
      const calls = await api.get<any[]>('/tables/waiter-calls');
      if (Array.isArray(calls)) {
        const newCalls = calls.filter((c) => !prevWaiterCallIdsRef.current.has(c.id));
        if (newCalls.length > 0 && !isInitialLoadRef.current) {
          playNotificationSound('bell');
        }
        prevWaiterCallIdsRef.current = new Set(calls.map((c) => c.id));
        setWaiterCalls(calls);
      }
    } catch (e) {
      // silent
    }
  };

  const handleResolveWaiterCall = async (callId: string) => {
    try {
      await api.put(`/tables/waiter-calls/${callId}/resolve`);
      setWaiterCalls((prev) => prev.filter((c) => c.id !== callId));
    } catch (e) {
      // ignore
    }
  };

  const fetchCurrentShift = async () => {
    try {
      const res = await api.get<Shift>('/shifts/current');
      if (res && res.id) {
        setCurrentShift(res);
      } else {
        setCurrentShift(null);
        // Prompt cashier to open shift if not opened
        setIsOpenShiftModalOpen(true);
      }
    } catch (err) {
      console.error('Failed to fetch current shift:', err);
      setCurrentShift(null);
    } finally {
      setShiftChecking(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    fetchWaiterCalls();
    fetchCurrentShift();
    api.get<any>('/tenants/profile').then((res) => {
      if (res) setTenantProfile(res);
    }).catch(() => {});

    const interval = setInterval(() => {
      fetchOrders();
      fetchWaiterCalls();
      api.get<Shift>('/shifts/current').then((res) => {
        if (res && res.id) setCurrentShift(res);
      }).catch(() => {});
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleOpenShift = async (e: React.FormEvent) => {
    e.preventDefault();
    setShiftSubmitting(true);
    setShiftError('');
    try {
      const res = await api.post<Shift>('/shifts/open', {
        shiftName: openShiftName.trim() || 'Shift Pagi',
        initialCash: Number(openInitialCash) || 0,
      });
      setCurrentShift(res);
      setIsOpenShiftModalOpen(false);
    } catch (err: any) {
      setShiftError(err?.message || 'Gagal membuka shift kasir');
    } finally {
      setShiftSubmitting(false);
    }
  };

  const handleOpenCloseShiftModal = async () => {
    if (!currentShift) return;
    setShiftError('');
    setCloseActualCash('');
    setCloseNotes('');
    try {
      const summary = await api.get(`/shifts/${currentShift.id}/summary`);
      setShiftSummary(summary);
      setIsCloseShiftModalOpen(true);
    } catch (err: any) {
      alert(err?.message || 'Gagal memuat ringkasan shift');
    }
  };

  const handleCloseShift = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentShift) return;
    if (closeActualCash === '' || isNaN(Number(closeActualCash))) {
      setShiftError('Harap masukkan nominal uang fisik di laci kasir');
      return;
    }

    setShiftSubmitting(true);
    setShiftError('');
    try {
      await api.post(`/shifts/${currentShift.id}/close`, {
        actualCash: Number(closeActualCash),
        notes: closeNotes.trim() || undefined,
      });
      setIsCloseShiftModalOpen(false);
      setCurrentShift(null);
      alert('Shift kasir berhasil ditutup dan direkonsiliasi. Terima kasih!');
    } catch (err: any) {
      setShiftError(err?.message || 'Gagal menutup shift');
    } finally {
      setShiftSubmitting(false);
    }
  };

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    if (!currentShift && ['CASHIER', 'ADMIN', 'OWNER'].includes(user?.role || '')) {
      alert('Perhatian: Anda belum membuka shift kasir. Silakan buka shift terlebih dahulu untuk mencatat transaksi kasir.');
      setIsOpenShiftModalOpen(true);
      return;
    }

    try {
      await api.put(`/orders/${orderId}/status`, { status: newStatus });
      fetchOrders();
      if (selectedOrder?.id === orderId) {
        setSelectedOrder((prev) => (prev ? { ...prev, status: newStatus } : null));
      }
      if (currentShift) {
        api.get<Shift>('/shifts/current').then((res) => {
          if (res && res.id) setCurrentShift(res);
        }).catch(() => {});
      }
    } catch (err: any) {
      alert(err.message || 'Gagal mengubah status pesanan');
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    const reason = prompt('Masukkan alasan pembatalan order:');
    if (!reason) return;

    try {
      await api.post(`/orders/${orderId}/cancel`, { reason });
      fetchOrders();
      if (selectedOrder?.id === orderId) {
        setSelectedOrder((prev) => (prev ? { ...prev, status: 'CANCELLED' } : null));
      }
    } catch (err: any) {
      alert(err.message || 'Gagal membatalkan order');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
      </div>
    );
  }

  // Filter orders by search
  const filteredOrders = orders.filter((o) => {
    if (!searchQuery) return true;
    return (
      o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.customerName && o.customerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (o.table?.tableNumber && o.table.tableNumber.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  // Kanban Columns
  const columns = [
    {
      title: 'Menunggu Pembayaran',
      statuses: ['PENDING_PAYMENT', 'DRAFT'] as OrderStatus[],
      bgColor: 'bg-orange-50/70',
      badgeColor: 'bg-orange-100 text-orange-800',
    },
    {
      title: 'Dikonfirmasi',
      statuses: ['PAID', 'CONFIRMED'] as OrderStatus[],
      bgColor: 'bg-blue-50/70',
      badgeColor: 'bg-blue-100 text-blue-800',
    },
    {
      title: 'Dimasak (Kitchen)',
      statuses: ['PREPARING'] as OrderStatus[],
      bgColor: 'bg-amber-50/70',
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      title: 'Siap Antar',
      statuses: ['READY', 'OUT_FOR_DELIVERY'] as OrderStatus[],
      bgColor: 'bg-purple-50/70',
      badgeColor: 'bg-purple-100 text-purple-800',
    },
    {
      title: 'Selesai',
      statuses: ['DELIVERED', 'COMPLETED'] as OrderStatus[],
      bgColor: 'bg-emerald-50/70',
      badgeColor: 'bg-emerald-100 text-emerald-800',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <StaffNavbar />

      {/* Shift Status Banner */}
      {!shiftChecking && (
        currentShift ? (
          <div className="bg-amber-50 border-b border-amber-200/80 px-4 sm:px-6 py-2.5">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Shift Aktif: {currentShift.shiftName}
                </span>
                <span className="text-gray-600">
                  Kasir: <strong className="text-gray-900">{currentShift.cashier?.fullName || user?.fullName}</strong>
                </span>
                <span className="hidden md:inline text-gray-400">•</span>
                <span className="text-gray-600">
                  Modal Awal: <strong className="text-gray-900 font-mono">{formatRupiah(currentShift.initialCash)}</strong>
                </span>
                {currentShift.summary && (
                  <>
                    <span className="hidden md:inline text-gray-400">•</span>
                    <span className="text-gray-600">
                      Omzet Shift: <strong className="text-emerald-700 font-mono">{formatRupiah(currentShift.summary.totalSales)}</strong>
                    </span>
                    <span className="hidden md:inline text-gray-400">•</span>
                    <span className="text-gray-600">
                      Est. Kas Laci: <strong className="text-amber-900 font-mono">{formatRupiah(currentShift.summary.expectedCash)}</strong>
                    </span>
                  </>
                )}
              </div>

              <button
                onClick={handleOpenCloseShiftModal}
                className="px-3 py-1.5 bg-white hover:bg-red-50 border border-red-200 text-red-600 rounded-xl font-bold transition flex items-center gap-1.5 self-start sm:self-auto cursor-pointer shadow-2xs text-xs"
              >
                <Coins className="w-3.5 h-3.5" />
                <span>Tutup Shift Kasir</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-orange-50 border-b border-orange-200 px-4 sm:px-6 py-2.5">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-orange-800 font-medium">
                <AlertCircle className="w-4 h-4 text-orange-600 shrink-0" />
                <span>Anda belum membuka shift kasir. Buka shift untuk memulai pencatatan kas laci dan transaksi.</span>
              </div>
              <button
                onClick={() => {
                  setShiftError('');
                  setIsOpenShiftModalOpen(true);
                }}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 self-start sm:self-auto cursor-pointer shadow-xs text-xs"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Buka Shift Sekarang</span>
              </button>
            </div>
          </div>
        )
      )}

      {/* Active Waiter Calls Alert Banner */}
      {waiterCalls.length > 0 && (
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-4 sm:px-6 py-2.5 shadow-md animate-in slide-in-from-top duration-200">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black">
              <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
              <Bell className="w-4 h-4" />
              <span>Ada {waiterCalls.length} Panggilan Meja Pelanggan:</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {waiterCalls.map((call) => (
                <div key={call.id} className="flex items-center gap-2 bg-white/20 border border-white/20 px-3 py-1 rounded-xl text-xs backdrop-blur-xs">
                  <span className="font-black">Meja {call.tableNumber}</span>
                  <span className="text-[11px] text-purple-100 font-medium">
                    ({call.type === 'REQUEST_BILL' ? 'Minta Bill' : call.type === 'NEED_UTENSILS' ? 'Alat Makan' : 'Butuh Pelayan'})
                  </span>
                  {call.notes && (
                    <span className="text-[10px] text-purple-200 italic max-w-[120px] truncate">&quot;{call.notes}&quot;</span>
                  )}
                  <button
                    type="button"
                    onClick={() => handleResolveWaiterCall(call.id)}
                    className="ml-1 text-[10px] font-black bg-white text-purple-900 px-2.5 py-0.5 rounded-lg hover:bg-purple-100 transition shadow-2xs"
                  >
                    Selesai
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* POS Toolbar */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-3 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <h1 className="text-xl font-extrabold text-gray-900 tracking-tight">
              Order Board (Kanban)
            </h1>
            <span className="text-xs font-semibold bg-gray-100 text-gray-700 px-2.5 py-1 rounded-full">
              {filteredOrders.length} Pesanan
            </span>
          </div>

          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Audio Toggle in POS */}
            <button
              type="button"
              onClick={toggleMute}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition ${
                audioMuted
                  ? 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
              }`}
              title={audioMuted ? 'Suara Dinonaktifkan (Klik untuk aktifkan)' : 'Suara Aktif (Klik untuk mute)'}
            >
              {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{audioMuted ? 'Suara Off' : 'Suara On'}</span>
            </button>

            <button
              type="button"
              onClick={() => testAudioNotification('order')}
              className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-gray-50 hover:bg-gray-100 text-gray-700 transition border border-gray-200"
              title="Tes Suara Notifikasi"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Tes Ting</span>
            </button>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Cari order, meja, nama..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <button
              onClick={() => fetchOrders(true)}
              disabled={refreshing}
              className="p-2 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-xl transition flex items-center space-x-1 text-xs font-semibold shrink-0"
              title="Refresh"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-amber-600' : ''}`} />
              <span className="hidden md:inline">Perbarui</span>
            </button>
          </div>
        </div>
      </div>

      {/* Kanban Board Columns Container */}
      <div className="flex-1 overflow-x-auto p-4 sm:p-6">
        <div className="flex gap-4 min-w-[1200px] h-full items-start">
          {columns.map((col) => {
            const colOrders = filteredOrders.filter((o) => col.statuses.includes(o.status));

            return (
              <div
                key={col.title}
                className="flex-1 bg-gray-50 rounded-2xl border border-gray-200/80 p-3.5 flex flex-col max-h-[calc(100vh-140px)] min-w-[240px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-3 border-b border-gray-200 mb-3 shrink-0">
                  <span className="font-bold text-xs text-gray-800 uppercase tracking-wider">
                    {col.title}
                  </span>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${col.badgeColor}`}>
                    {colOrders.length}
                  </span>
                </div>

                {/* Cards List */}
                <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                  {colOrders.length === 0 ? (
                    <div className="py-8 text-center text-gray-400 text-xs">Tidak ada pesanan</div>
                  ) : (
                    colOrders.map((order) => (
                      <div
                        key={order.id}
                        className="bg-white p-3.5 rounded-xl border border-gray-200 shadow-xs hover:shadow-md transition space-y-2.5"
                      >
                        {/* Header: Order Number & Table */}
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center space-x-1.5">
                              <span className="text-xs font-mono font-bold text-gray-900">
                                #{order.orderNumber}
                              </span>
                              {order.status === 'PAID' && (
                                <span className="text-[9px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                                  Lunas
                                </span>
                              )}
                              {order.status === 'CONFIRMED' && (
                                <span className="text-[9px] font-bold bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded">
                                  Dikonfirmasi
                                </span>
                              )}
                              {order.status === 'PENDING_PAYMENT' && (
                                <span className="text-[9px] font-bold bg-orange-100 text-orange-800 px-1.5 py-0.5 rounded">
                                  Belum Bayar
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] font-bold text-amber-800 block mt-0.5">
                              {order.table?.tableNumber ? `Meja ${order.table.tableNumber}` : 'Takeaway'}
                            </span>
                          </div>
                          <span className="text-[10px] text-gray-400 font-mono">
                            {formatTime(order.createdAt)}
                          </span>
                        </div>

                        {/* Customer info */}
                        {order.customerName && (
                          <div className="text-xs text-gray-700 font-medium truncate">
                            {order.customerName}
                          </div>
                        )}

                        {/* Items Summary (compact) */}
                        <div className="text-xs text-gray-600 divide-y divide-gray-50 border-t border-b border-gray-50 py-1">
                          {order.items.map((item) => (
                            <div key={item.id} className="py-0.5 flex justify-between">
                              <span className="truncate pr-2">
                                {item.quantity}x {item.productName}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Total & Quick Action */}
                        <div className="flex justify-between items-center pt-1">
                          <span className="font-extrabold text-xs text-gray-900">
                            {formatRupiah(order.totalAmount)}
                          </span>

                          <button
                            onClick={() => setSelectedOrder(order)}
                            className="p-1 text-gray-500 hover:text-amber-600 hover:bg-gray-100 rounded-lg transition"
                            title="Lihat Detail"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Status Action Buttons */}
                        <div className="pt-2 border-t border-gray-100 flex gap-1.5">
                          {order.status === 'PENDING_PAYMENT' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'PAID')}
                              className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1 shadow-xs cursor-pointer"
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Konfirmasi Bayar</span>
                            </button>
                          )}

                          {['PAID', 'CONFIRMED'].includes(order.status) && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'PREPARING')}
                              className="flex-1 py-1.5 px-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1 shadow-xs cursor-pointer"
                            >
                              <UtensilsCrossed className="w-3 h-3" />
                              <span>Kirim ke Dapur</span>
                            </button>
                          )}

                          {order.status === 'PREPARING' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'READY')}
                              className="flex-1 py-1.5 px-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1"
                            >
                              <ConciergeBell className="w-3 h-3" />
                              <span>Siap</span>
                            </button>
                          )}

                          {order.status === 'READY' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'OUT_FOR_DELIVERY')}
                              className="flex-1 py-1.5 px-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1"
                            >
                              <ConciergeBell className="w-3 h-3" />
                              <span>Antar</span>
                            </button>
                          )}

                          {order.status === 'OUT_FOR_DELIVERY' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'DELIVERED')}
                              className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1"
                            >
                              <CheckCheck className="w-3 h-3" />
                              <span>Terkirim</span>
                            </button>
                          )}

                          {order.status === 'DELIVERED' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'COMPLETED')}
                              className="flex-1 py-1.5 px-2 bg-gray-800 hover:bg-black text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1"
                            >
                              <span>Selesai</span>
                            </button>
                          )}

                          {!['COMPLETED', 'CANCELLED', 'DELIVERED'].includes(order.status) && (
                            <button
                              onClick={() => handleCancelOrder(order.id)}
                              className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-[11px] transition"
                              title="Batalkan Pesanan"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-gray-900 text-base">
                  Rincian Order #{selectedOrder.orderNumber}
                </h3>
                <span className="text-xs text-gray-500">
                  {selectedOrder.table?.tableNumber
                    ? `Meja ${selectedOrder.table.tableNumber}`
                    : 'Takeaway'}{' '}
                  • {selectedOrder.customerName || 'Customer'}
                </span>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 max-h-[70vh] overflow-y-auto space-y-4">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Status</span>
                  <span className="text-xs font-bold text-amber-800">{selectedOrder.status}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Waktu</span>
                  <span className="text-xs font-medium text-gray-600">
                    {formatTime(selectedOrder.createdAt)}
                  </span>
                </div>
              </div>

              {selectedOrder.customerNotes && (
                <div className="p-3 bg-amber-50/60 rounded-xl text-xs text-amber-900 border border-amber-100">
                  <span className="font-bold block mb-0.5">Catatan Customer:</span>
                  &quot;{selectedOrder.customerNotes}&quot;
                </div>
              )}

              {/* Items List */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                  Daftar Menu
                </span>
                <div className="divide-y divide-gray-100 border border-gray-100 rounded-xl overflow-hidden">
                  {selectedOrder.items.map((item) => (
                    <div key={item.id} className="p-3 flex justify-between items-start text-xs">
                      <div>
                        <div className="font-bold text-gray-900">
                          {item.quantity}x {item.productName}
                        </div>
                        {item.variantName && (
                          <div className="text-gray-500">Varian: {item.variantName}</div>
                        )}
                        {item.modifiers && item.modifiers.length > 0 && (
                          <div className="text-gray-400 text-[11px]">
                            {item.modifiers.map((m) => m.modifierOptionName).join(', ')}
                          </div>
                        )}
                        {item.notes && (
                          <div className="text-amber-700 italic text-[11px]">&quot;{item.notes}&quot;</div>
                        )}
                      </div>
                      <div className="font-semibold text-gray-900">
                        {formatRupiah(item.totalPrice ?? item.subtotal ?? (Number(item.unitPrice) * item.quantity))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Breakdown */}
              <div className="p-3 bg-gray-50 rounded-xl space-y-1.5 text-xs text-gray-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{formatRupiah(selectedOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Pajak (10%)</span>
                  <span>{formatRupiah(selectedOrder.taxAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Service (5%)</span>
                  <span>{formatRupiah(selectedOrder.serviceChargeAmount)}</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-gray-900 pt-2 border-t border-gray-200">
                  <span>Total Tagihan</span>
                  <span className="text-amber-800">{formatRupiah(selectedOrder.totalAmount)}</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
              <button
                onClick={() => {
                  setReceiptOrder(selectedOrder);
                }}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-sm cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Struk Thermal</span>
              </button>

              <button
                onClick={() => setSelectedOrder(null)}
                className="px-4 py-2 bg-gray-800 text-white rounded-xl text-xs font-semibold hover:bg-black transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Thermal Receipt Print Modal */}
      {receiptOrder && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-4 font-mono text-gray-800">
            {/* Action Bar */}
            <div className="flex justify-between items-center pb-2 border-b border-gray-100 not-printable">
              <span className="text-xs font-bold text-gray-500 font-sans uppercase">Struk Pembayaran (58mm/80mm)</span>
              <button
                onClick={() => setReceiptOrder(null)}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-full"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Printable Receipt Paper */}
            <div className="bg-amber-50/40 p-5 rounded-2xl border border-dashed border-amber-200 text-center space-y-3">
              {tenantProfile?.logoUrl && (
                <img
                  src={tenantProfile.logoUrl}
                  alt="Logo"
                  className="w-12 h-12 object-contain mx-auto rounded-lg mb-1"
                />
              )}
              <div>
                <h3 className="text-base font-black tracking-tight text-gray-900">
                  {tenantProfile?.name || 'Cafe POS'}
                </h3>
                {tenantProfile?.tagline && (
                  <p className="text-[10px] text-gray-500 italic">{tenantProfile.tagline}</p>
                )}
                {tenantProfile?.address && (
                  <p className="text-[10px] text-gray-500 mt-0.5">{tenantProfile.address}</p>
                )}
                {tenantProfile?.phone && (
                  <p className="text-[10px] text-gray-500">{tenantProfile.phone}</p>
                )}
              </div>

              <div className="border-t border-dashed border-gray-300 my-2"></div>

              {/* Meta */}
              <div className="text-[11px] text-left space-y-1">
                <div className="flex justify-between">
                  <span>No. Order:</span>
                  <span className="font-bold">#{receiptOrder.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>Meja / Tipe:</span>
                  <span className="font-bold">
                    {receiptOrder.table?.tableNumber ? `Meja ${receiptOrder.table.tableNumber}` : 'Takeaway'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Waktu:</span>
                  <span>{formatTime(receiptOrder.createdAt)}</span>
                </div>
                {receiptOrder.customerName && (
                  <div className="flex justify-between">
                    <span>Pelanggan:</span>
                    <span>{receiptOrder.customerName}</span>
                  </div>
                )}
              </div>

              <div className="border-t border-dashed border-gray-300 my-2"></div>

              {/* Items */}
              <div className="text-[11px] text-left space-y-1.5">
                {receiptOrder.items.map((it) => (
                  <div key={it.id}>
                    <div className="flex justify-between font-semibold">
                      <span>{it.quantity}x {it.productName}</span>
                      <span>{formatRupiah(it.totalPrice ?? it.subtotal ?? (Number(it.unitPrice) * it.quantity))}</span>
                    </div>
                    {it.variantName && (
                      <span className="text-[10px] text-gray-500 block pl-4">Varian: {it.variantName}</span>
                    )}
                  </div>
                ))}
              </div>

              <div className="border-t border-dashed border-gray-300 my-2"></div>

              {/* Totals */}
              <div className="text-[11px] text-left space-y-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatRupiah(receiptOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Pajak (10%):</span>
                  <span>{formatRupiah(receiptOrder.taxAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Service (5%):</span>
                  <span>{formatRupiah(receiptOrder.serviceChargeAmount)}</span>
                </div>
                <div className="flex justify-between font-bold text-xs pt-1 border-t border-gray-200">
                  <span>TOTAL:</span>
                  <span>{formatRupiah(receiptOrder.totalAmount)}</span>
                </div>
              </div>

              <div className="border-t border-dashed border-gray-300 my-2"></div>

              {/* Receipt Footer Note */}
              <p className="text-[10px] text-gray-500 font-sans italic text-center">
                {tenantProfile?.receiptFooter || 'Terima kasih atas kunjungan Anda!'}
              </p>
            </div>

            {/* Print Button */}
            <div className="flex gap-2 font-sans pt-2">
              <button
                type="button"
                onClick={() => setReceiptOrder(null)}
                className="flex-1 py-2 px-3 border border-gray-200 rounded-xl text-xs font-bold hover:bg-gray-50 transition"
              >
                Tutup
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="flex-1 py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 shadow-sm cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Thermal</span>
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Open Shift Modal */}
      {isOpenShiftModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-5 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 text-base">Buka Shift Kasir</h3>
                  <p className="text-xs text-gray-400">Mulai sesi kasir baru untuk mencatat transaksi</p>
                </div>
              </div>
              {currentShift && (
                <button
                  onClick={() => setIsOpenShiftModalOpen(false)}
                  className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            <form onSubmit={handleOpenShift} className="p-5 space-y-4">
              {shiftError && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{shiftError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Nama Sesi Shift *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Shift Pagi / Shift Sore"
                  value={openShiftName}
                  onChange={(e) => setOpenShiftName(e.target.value)}
                  className="w-full text-xs px-3 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <div className="flex gap-1.5 mt-2">
                  {['Shift Pagi', 'Shift Sore', 'Shift Malam'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setOpenShiftName(preset)}
                      className="px-2.5 py-1 text-[11px] font-semibold bg-gray-100 hover:bg-amber-50 hover:text-amber-800 text-gray-600 rounded-lg transition"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Modal Awal Kas di Laci (Cash Drawer) *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-gray-400">Rp</span>
                  <input
                    type="number"
                    required
                    min="0"
                    step="1000"
                    placeholder="100000"
                    value={openInitialCash}
                    onChange={(e) => setOpenInitialCash(e.target.value)}
                    className="w-full text-xs pl-9 pr-3 py-2.5 border border-gray-200 rounded-xl font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div className="flex gap-1.5 mt-2">
                  {[50000, 100000, 200000, 500000].map((nominal) => (
                    <button
                      key={nominal}
                      type="button"
                      onClick={() => setOpenInitialCash(nominal)}
                      className="px-2 py-1 text-[10px] font-mono font-semibold bg-gray-100 hover:bg-amber-50 hover:text-amber-800 text-gray-600 rounded-lg transition"
                    >
                      {formatRupiah(nominal)}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-100 text-[11px] text-amber-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <Banknote className="w-3.5 h-3.5" />
                  <span>Petunjuk Kasir:</span>
                </div>
                <p>
                  Hitung uang kembalian/modal kas di laci kasir sebelum membuka shift. Nominal ini akan dijadikan acuan rekonsiliasi kas saat shift ditutup.
                </p>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-end gap-2">
                {currentShift && (
                  <button
                    type="button"
                    onClick={() => setIsOpenShiftModalOpen(false)}
                    className="px-4 py-2 border border-gray-200 text-gray-600 rounded-xl text-xs font-semibold hover:bg-gray-50 transition"
                  >
                    Batal
                  </button>
                )}
                <button
                  type="submit"
                  disabled={shiftSubmitting}
                  className="w-full sm:w-auto px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {shiftSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Buka Shift Sekarang</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Close Shift Modal with Reconciliation */}
      {isCloseShiftModalOpen && shiftSummary && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 max-h-[90vh] flex flex-col">
            <div className="p-5 border-b border-gray-100 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 flex items-center justify-center">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 text-base">Tutup Shift & Rekonsiliasi Kas</h3>
                  <p className="text-xs text-gray-400">
                    {shiftSummary.shift?.shiftName} • {user?.fullName}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCloseShiftModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCloseShift} className="p-5 overflow-y-auto space-y-4">
              {shiftError && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{shiftError}</span>
                </div>
              )}

              {/* Financial Stats Cards */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Total Pesanan</span>
                  <span className="text-base font-black text-gray-900">
                    {shiftSummary.summary?.ordersCount || 0} Transaksi
                  </span>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Total Omzet Shift</span>
                  <span className="text-base font-black text-amber-800 font-mono">
                    {formatRupiah(shiftSummary.summary?.totalSales || 0)}
                  </span>
                </div>
              </div>

              {/* Breakdown */}
              <div className="p-3.5 bg-amber-50/50 rounded-xl border border-amber-100 space-y-2 text-xs text-gray-700">
                <div className="flex justify-between items-center">
                  <span>Modal Awal (Kas Drawer):</span>
                  <span className="font-mono font-bold">{formatRupiah(shiftSummary.summary?.initialCash || 0)}</span>
                </div>
                <div className="flex justify-between items-center text-emerald-800 font-medium">
                  <span>(+) Pembayaran Tunai (Cash):</span>
                  <span className="font-mono font-bold">{formatRupiah(shiftSummary.summary?.totalCash || 0)}</span>
                </div>
                <div className="flex justify-between items-center text-blue-700 font-medium">
                  <span>Pembayaran Non-Tunai (QRIS / Xendit):</span>
                  <span className="font-mono font-bold">{formatRupiah(shiftSummary.summary?.totalNonCash || 0)}</span>
                </div>
                <div className="pt-2 border-t border-amber-200 flex justify-between items-center text-sm font-black text-gray-900">
                  <span>(=) Estimasi Uang Kas di Laci:</span>
                  <span className="font-mono text-amber-900">{formatRupiah(shiftSummary.summary?.expectedCash || 0)}</span>
                </div>
              </div>

              {/* Physical cash input */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-gray-900">
                  Uang Fisik Kasir di Laci (Hasil Hitung Fisik) *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-gray-400">Rp</span>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="Hitung seluruh uang tunai di laci dan masukkan di sini"
                    value={closeActualCash}
                    onChange={(e) => setCloseActualCash(e.target.value)}
                    className="w-full text-sm pl-9 pr-3 py-2.5 border-2 border-amber-500 rounded-xl font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 bg-amber-50/20"
                  />
                </div>
              </div>

              {/* Discrepancy indicator */}
              {closeActualCash !== '' && !isNaN(Number(closeActualCash)) && (
                <div
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs font-bold ${
                    Number(closeActualCash) - Number(shiftSummary.summary?.expectedCash || 0) === 0
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : Number(closeActualCash) - Number(shiftSummary.summary?.expectedCash || 0) < 0
                      ? 'bg-red-50 border-red-200 text-red-800'
                      : 'bg-blue-50 border-blue-200 text-blue-800'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    {Number(closeActualCash) - Number(shiftSummary.summary?.expectedCash || 0) === 0 ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <AlertTriangle className="w-4 h-4" />
                    )}
                    <span>
                      {Number(closeActualCash) - Number(shiftSummary.summary?.expectedCash || 0) === 0
                        ? 'Kas Cocok / Pas'
                        : Number(closeActualCash) - Number(shiftSummary.summary?.expectedCash || 0) < 0
                        ? 'Kas Kurang (Defisit)'
                        : 'Kas Lebih (Surplus)'}
                    </span>
                  </div>
                  <span className="font-mono text-sm">
                    {formatRupiah(Number(closeActualCash) - Number(shiftSummary.summary?.expectedCash || 0))}
                  </span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Catatan Penutupan Shift (Opsional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Keterangan serah terima, alasan selisih uang, dll."
                  value={closeNotes}
                  onChange={(e) => setCloseNotes(e.target.value)}
                  className="w-full text-xs p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                ></textarea>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCloseShiftModalOpen(false)}
                  className="px-4 py-2 border border-gray-200 text-gray-600 rounded-xl text-xs font-semibold hover:bg-gray-50 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={shiftSubmitting}
                  className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {shiftSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Konfirmasi & Tutup Shift</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

