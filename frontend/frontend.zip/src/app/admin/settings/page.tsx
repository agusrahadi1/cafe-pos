'use client';

import React, { useEffect, useState } from 'react';
import Script from 'next/script';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/lib/api';
import StaffNavbar from '@/components/layout/StaffNavbar';
import { formatRupiah, getImageUrl } from '@/lib/utils';
import {
  Store,
  Image as ImageIcon,
  FileText,
  Phone,
  MapPin,
  Save,
  CheckCircle2,
  AlertCircle,
  Loader2,
  PackageCheck,
  Utensils,
  Users,
  ExternalLink,
  Upload,
  Trash2,
  QrCode,
  Zap,
  CreditCard,
  Sparkles,
  ShieldCheck,
  X,
  Clock,
} from 'lucide-react';

declare global {
  interface Window {
    snap?: any;
  }
}

export default function TenantSettingsPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [tenant, setTenant] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Form Fields
  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [qrisImageUrl, setQrisImageUrl] = useState('');
  const [receiptFooter, setReceiptFooter] = useState('');
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [isUploadingQris, setIsUploadingQris] = useState(false);
  const [isJustSaved, setIsJustSaved] = useState(false);
  const [showSavedToast, setShowSavedToast] = useState(false);

  // Subscription Renewal Modal
  const [isRenewalModalOpen, setIsRenewalModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'starter' | 'pro' | 'enterprise'>('pro');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [submittingSubscription, setSubmittingSubscription] = useState(false);
  const [renewalError, setRenewalError] = useState('');

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Hanya file gambar (PNG, JPG, SVG, WEBP) yang diperbolehkan untuk logo');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Ukuran logo maksimal 5MB');
      return;
    }

    setIsUploadingLogo(true);
    setErrorMsg('');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await api.upload<{ url: string }>('/uploads/image?folder=logos', formData);
      if (res?.url) {
        setLogoUrl(res.url);
        setSuccessMsg('Logo berhasil diunggah! Klik "Simpan Pengaturan" untuk menerapkan.');
        setTimeout(() => setSuccessMsg(''), 4000);
      }
    } catch (err: any) {
      console.error('Error uploading logo:', err);
      setErrorMsg(err?.message || 'Gagal mengunggah logo');
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleQrisUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Hanya file gambar barcode (PNG, JPG, WEBP) yang diperbolehkan untuk QRIS');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Ukuran gambar QRIS maksimal 5MB');
      return;
    }

    setIsUploadingQris(true);
    setErrorMsg('');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await api.upload<{ url: string }>('/uploads/image?folder=logos', formData);
      if (res?.url) {
        setQrisImageUrl(res.url);
        setSuccessMsg('Barcode QRIS berhasil diunggah! Klik "Simpan Pengaturan" untuk menerapkan.');
        setTimeout(() => setSuccessMsg(''), 4000);
      }
    } catch (err: any) {
      console.error('Error uploading QRIS:', err);
      setErrorMsg(err?.message || 'Gagal mengunggah gambar QRIS');
    } finally {
      setIsUploadingQris(false);
    }
  };

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const fetchProfile = async () => {
    try {
      const res = await api.get<any>('/tenants/profile');
      if (res) {
        setTenant(res);
        setName(res.name || '');
        setTagline(res.tagline || '');
        setAddress(res.address || '');
        setPhone(res.phone || '');
        setLogoUrl(res.logoUrl || res.logo || '');
        setQrisImageUrl(res.qrisImageUrl || '');
        setReceiptFooter(res.receiptFooter || '');
      }
    } catch (e: any) {
      console.error('Error fetching tenant profile:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMsg('');
    setSuccessMsg('');
    setIsJustSaved(false);

    try {
      await api.put('/tenants/profile', {
        name,
        tagline: tagline || undefined,
        address: address || undefined,
        phone: phone || undefined,
        logoUrl: logoUrl || undefined,
        qrisImageUrl: qrisImageUrl || null,
        receiptFooter: receiptFooter || undefined,
      });

      setIsJustSaved(true);
      setShowSavedToast(true);
      setSuccessMsg('Profil, logo & QRIS kafe berhasil disimpan!');

      setTimeout(() => {
        setIsJustSaved(false);
      }, 3000);

      setTimeout(() => {
        setShowSavedToast(false);
        setSuccessMsg('');
      }, 4500);

      await fetchProfile();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal menyimpan pengaturan profil');
    } finally {
      setSaving(false);
    }
  };

  const handleCheckoutSubscription = async () => {
    setSubmittingSubscription(true);
    setRenewalError('');
    try {
      const res = await api.post<any>('/tenants/subscription/checkout', {
        planSlug: selectedPlan,
        billingCycle,
      });

      if (!res?.snapToken) {
        throw new Error('Gagal mendapatkan token transaksi Midtrans.');
      }

      if (typeof window !== 'undefined' && window.snap) {
        window.snap.pay(res.snapToken, {
          onSuccess: async (result: any) => {
            try {
              await api.post('/tenants/subscription/confirm', {
                orderId: res.orderId,
                planSlug: selectedPlan,
                durationMonths: res.durationMonths,
              });
              setSuccessMsg('Pembayaran Midtrans berhasil! Paket langganan telah aktif.');
              setIsRenewalModalOpen(false);
              await fetchProfile();
            } catch (e: any) {
              console.error('Confirm error:', e);
              await fetchProfile();
              setIsRenewalModalOpen(false);
            }
          },
          onPending: (result: any) => {
            setSuccessMsg('Menunggu pembayaran Midtrans diselesaikan.');
            setIsRenewalModalOpen(false);
          },
          onError: (result: any) => {
            setRenewalError('Pembayaran gagal atau transaksi dibatalkan.');
          },
          onClose: () => {
            console.log('Customer closed Midtrans Snap without paying');
          },
        });
      } else {
        if (res.redirectUrl) {
          window.location.href = res.redirectUrl;
        } else {
          throw new Error('Midtrans Snap SDK belum termuat.');
        }
      }
    } catch (err: any) {
      setRenewalError(err?.message || 'Terjadi kesalahan saat memproses transaksi langganan.');
    } finally {
      setSubmittingSubscription(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
      </div>
    );
  }

  const quotas = tenant?.quotas;
  const plan = tenant?.activeSubscription?.plan;

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <StaffNavbar />

      {/* Header Toolbar */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-gray-900 tracking-tight">
                Pengaturan Profil & Branding Kafe
              </h1>
              <p className="text-xs text-gray-500">
                Atur nama kafe, logo, informasi kontak, footer struk thermal, dan pantau kuota paket
              </p>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-5xl mx-auto w-full p-4 sm:p-6 space-y-6 flex-1">
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-3.5 rounded-2xl text-xs font-semibold flex items-center space-x-3 shadow-xs animate-in slide-in-from-top-3 fade-in duration-300">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5 animate-bounce" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-emerald-950">Berhasil Disimpan!</p>
              <p className="text-[11px] text-emerald-700 font-normal">{successMsg}</p>
            </div>
          </div>
        )}

        {errorMsg && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-2xl text-xs font-semibold flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-red-500" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Subscription & Quota Card */}
        <div className="bg-white rounded-3xl p-6 border border-gray-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
                <PackageCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900">Paket Langganan Kafe Anda</h3>
                <p className="text-[11px] text-gray-500">
                  Paket aktif: <strong className="text-amber-800">{plan?.name || 'Enterprise'}</strong>
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="text-xs text-gray-500">
                Masa Aktif:{' '}
                <strong className="text-gray-900">
                  {tenant?.activeSubscription?.endDate
                    ? new Date(tenant.activeSubscription.endDate).toLocaleDateString('id-ID', {
                        dateStyle: 'long',
                      })
                    : 'Permanen'}
                </strong>
              </div>

              <button
                type="button"
                onClick={() => setIsRenewalModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-200 fill-amber-200" />
                <span>Perpanjang / Upgrade Paket</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Menu Quota */}
            <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-gray-700 flex items-center gap-1.5">
                  <Utensils className="w-3.5 h-3.5 text-amber-600" /> Kuota Menu Produk
                </span>
                <span className="font-bold text-gray-900">
                  {quotas?.products?.used || 0} /{' '}
                  {quotas?.products?.isUnlimited ? '∞ (Unlimited)' : quotas?.products?.max}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-amber-600 h-2 rounded-full transition-all"
                  style={{
                    width: quotas?.products?.isUnlimited
                      ? '15%'
                      : `${Math.min(100, ((quotas?.products?.used || 0) / (quotas?.products?.max || 1)) * 100)}%`,
                  }}
                ></div>
              </div>
            </div>

            {/* Staff Quota */}
            <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-gray-700 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-indigo-600" /> Kuota Akun Staf / Kasir
                </span>
                <span className="font-bold text-gray-900">
                  {quotas?.staff?.used || 0} /{' '}
                  {quotas?.staff?.isUnlimited ? '∞ (Unlimited)' : quotas?.staff?.max}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all"
                  style={{
                    width: quotas?.staff?.isUnlimited
                      ? '25%'
                      : `${Math.min(100, ((quotas?.staff?.used || 0) / (quotas?.staff?.max || 1)) * 100)}%`,
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Profile & Branding Form */}
        <form onSubmit={handleSave} className="bg-white rounded-3xl p-6 border border-gray-200 shadow-xs space-y-6">
          <div className="border-b border-gray-100 pb-3">
            <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <Store className="w-4 h-4 text-amber-600" />
              <span>Identitas & Informasi Kafe</span>
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Informasi ini akan muncul di header aplikasi, tampilan kasir POS, dan struk belanja
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                Nama Kafe / Restoran <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                Tagline / Slogan Kafe
              </label>
              <input
                type="text"
                placeholder="Contoh: Artisanal Coffee & Warm Pastry"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                Nomor Telepon / Kontak
              </label>
              <input
                type="text"
                placeholder="+62 21 555-0199"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

          </div>
 
          {/* Logo Kafe Upload Section */}
          <div className="bg-amber-50/50 p-5 rounded-3xl border border-amber-200/70 space-y-3">
            <label className="block text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-amber-700" />
                <span>Logo Kafe / Identitas Brand</span>
              </span>
              {isUploadingLogo && (
                <span className="text-[11px] text-amber-700 flex items-center gap-1 font-semibold">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Mengunggah logo...
                </span>
              )}
            </label>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              {/* Logo Preview */}
              <div className="w-20 h-20 rounded-2xl bg-white border-2 border-dashed border-amber-300 flex items-center justify-center p-2 shrink-0 relative group shadow-xs">
                {logoUrl ? (
                  <>
                    <img
                      src={getImageUrl(logoUrl)}
                      alt="Logo Preview"
                      className="w-full h-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={() => setLogoUrl('')}
                      className="absolute inset-0 bg-black/60 text-white rounded-2xl opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-xs font-bold"
                      title="Hapus Logo"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <div className="text-gray-300 flex flex-col items-center">
                    <Store className="w-6 h-6 stroke-1 text-amber-400" />
                    <span className="text-[9px] text-gray-400 mt-1 font-medium">Belum Ada</span>
                  </div>
                )}
              </div>

              {/* Upload button & details */}
              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <label className="inline-flex items-center space-x-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold cursor-pointer transition shadow-xs">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{logoUrl ? 'Ganti File Logo' : 'Upload File Logo'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      disabled={isUploadingLogo}
                      onChange={handleLogoUpload}
                      className="hidden"
                    />
                  </label>
                  {logoUrl && (
                    <button
                      type="button"
                      onClick={() => setLogoUrl('')}
                      className="px-3 py-2 border border-gray-200 hover:bg-red-50 hover:text-red-700 text-gray-600 rounded-xl text-xs font-semibold transition"
                    >
                      Hapus Logo
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-gray-500 leading-tight">
                  Format PNG transparan, JPG, SVG, atau WEBP (Maksimal 5MB). Logo akan disematkan secara otomatis di header kafe, dashboard kasir, katalog QR meja, dan struk thermal POS.
                </p>
              </div>
            </div>
          </div>

          {/* QRIS Pembayaran Kafe Upload Section */}
          <div className="bg-emerald-50/50 p-5 rounded-3xl border border-emerald-200/70 space-y-3">
            <label className="block text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <QrCode className="w-4 h-4 text-emerald-700" />
                <span>Barcode QRIS Kafe (Metode Pembayaran Mandiri)</span>
              </span>
              {isUploadingQris && (
                <span className="text-[11px] text-emerald-700 flex items-center gap-1 font-semibold">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Mengunggah QRIS...
                </span>
              )}
            </label>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              {/* QRIS Preview */}
              <div className="w-24 h-24 rounded-2xl bg-white border-2 border-dashed border-emerald-300 flex items-center justify-center p-2 shrink-0 relative group shadow-xs">
                {qrisImageUrl ? (
                  <>
                    <img
                      src={getImageUrl(qrisImageUrl)}
                      alt="QRIS Preview"
                      className="w-full h-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={() => setQrisImageUrl('')}
                      className="absolute inset-0 bg-black/60 text-white rounded-2xl opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-xs font-bold cursor-pointer"
                      title="Hapus Barcode QRIS"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <div className="text-gray-300 flex flex-col items-center">
                    <QrCode className="w-8 h-8 stroke-1 text-emerald-400" />
                    <span className="text-[9px] text-gray-400 mt-1 font-medium text-center">Belum Ada QRIS</span>
                  </div>
                )}
              </div>

              {/* Upload button & details */}
              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <label className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold cursor-pointer transition shadow-xs">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{qrisImageUrl ? 'Ganti Barcode QRIS' : 'Upload Barcode QRIS Kafe'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      disabled={isUploadingQris}
                      onChange={handleQrisUpload}
                      className="hidden"
                    />
                  </label>
                  {qrisImageUrl && (
                    <button
                      type="button"
                      onClick={() => setQrisImageUrl('')}
                      className="px-3 py-2 border border-gray-200 hover:bg-red-50 hover:text-red-700 text-gray-600 rounded-xl text-xs font-semibold transition cursor-pointer"
                    >
                      Hapus QRIS
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-gray-500 leading-tight">
                  Unggah gambar barcode QRIS kafe Anda (format PNG/JPG). Barcode ini akan langsung muncul kepada pelanggan di keranjang belanja meja dan halaman pelacakan status pesanan saat mereka memilih metode pembayaran <strong>QRIS</strong>.
                </p>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
              Alamat Lengkap Kafe
            </label>
            <textarea
              rows={2}
              placeholder="Jl. Senopati No. 45, Jakarta Selatan"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
            ></textarea>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
              Pesan Footer Struk Thermal Kasir
            </label>
            <textarea
              rows={2}
              placeholder="Terima kasih atas kunjungan Anda! Follow Instagram @namakafe"
              value={receiptFooter}
              onChange={(e) => setReceiptFooter(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
            ></textarea>
            <span className="text-[10px] text-gray-400 mt-1 block">
              Teks ini dicetak di bagian paling bawah struk kasir dan invoice digital pelanggan.
            </span>
          </div>

          <div className="pt-4 border-t border-gray-100 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className={`py-2.5 px-6 rounded-xl text-xs font-bold transition-all duration-300 flex items-center space-x-2 shadow-md cursor-pointer ${
                isJustSaved
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white ring-4 ring-emerald-400/30 scale-105'
                  : 'bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50'
              }`}
            >
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Menyimpan...</span>
                </>
              ) : isJustSaved ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white animate-bounce" />
                  <span>Berhasil Disimpan!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Simpan Pengaturan Kafe</span>
                </>
              )}
            </button>
          </div>
        </form>
      </main>

      {/* Subscription Renewal / Upgrade Modal */}
      {isRenewalModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-gray-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-amber-700 to-amber-900 text-white flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center">
                  <Zap className="w-5 h-5 text-amber-300 fill-amber-300" />
                </div>
                <div>
                  <h3 className="text-base font-bold">Perpanjang / Upgrade Paket SaaS</h3>
                  <p className="text-xs text-amber-200">
                    Pembayaran instan & otomatis via Midtrans Payment Gateway
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsRenewalModalOpen(false)}
                className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {renewalError && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-medium rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{renewalError}</span>
                </div>
              )}

              {/* Billing Cycle Toggle */}
              <div className="flex items-center justify-center">
                <div className="bg-gray-100 p-1 rounded-2xl flex items-center space-x-1 border border-gray-200">
                  <button
                    type="button"
                    onClick={() => setBillingCycle('monthly')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                      billingCycle === 'monthly'
                        ? 'bg-white text-gray-900 shadow-xs'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Bulanan (1 Bulan)
                  </button>
                  <button
                    type="button"
                    onClick={() => setBillingCycle('yearly')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                      billingCycle === 'yearly'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    <span>Tahunan (12 Bulan)</span>
                    <span className="bg-amber-200 text-amber-900 text-[10px] px-1.5 py-0.5 rounded-full font-extrabold">
                      Hemat 2 Bulan
                    </span>
                  </button>
                </div>
              </div>

              {/* Plan Options */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Starter Plan */}
                <div
                  onClick={() => setSelectedPlan('starter')}
                  className={`p-4 rounded-2xl border-2 transition cursor-pointer relative flex flex-col justify-between ${
                    selectedPlan === 'starter'
                      ? 'border-amber-600 bg-amber-50/40 shadow-md ring-2 ring-amber-500/20'
                      : 'border-gray-200 hover:border-amber-300'
                  }`}
                >
                  <div className="space-y-2">
                    <h4 className="font-extrabold text-gray-900 text-sm">Starter</h4>
                    <p className="text-[11px] text-gray-500">Kedai kopi & kafe rintisan</p>
                    <div className="text-base font-black text-amber-800">
                      {billingCycle === 'monthly' ? 'Rp 99.000' : 'Rp 990.000'}
                      <span className="text-[10px] font-normal text-gray-500">
                        {billingCycle === 'monthly' ? '/bln' : '/thn'}
                      </span>
                    </div>
                    <ul className="text-[11px] text-gray-600 space-y-1.5 pt-2 border-t border-gray-100">
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>50 Menu Produk</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>3 Meja Kafe</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>2 Akun Staf / Kasir</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Pro Plan */}
                <div
                  onClick={() => setSelectedPlan('pro')}
                  className={`p-4 rounded-2xl border-2 transition cursor-pointer relative flex flex-col justify-between ${
                    selectedPlan === 'pro'
                      ? 'border-amber-600 bg-amber-50/40 shadow-md ring-2 ring-amber-500/20'
                      : 'border-gray-200 hover:border-amber-300'
                  }`}
                >
                  <div className="absolute -top-2.5 right-3 bg-amber-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                    POPULER
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-extrabold text-gray-900 text-sm">Pro</h4>
                    <p className="text-[11px] text-gray-500">Kafe ramai & berkembang</p>
                    <div className="text-base font-black text-amber-800">
                      {billingCycle === 'monthly' ? 'Rp 199.000' : 'Rp 1.990.000'}
                      <span className="text-[10px] font-normal text-gray-500">
                        {billingCycle === 'monthly' ? '/bln' : '/thn'}
                      </span>
                    </div>
                    <ul className="text-[11px] text-gray-600 space-y-1.5 pt-2 border-t border-gray-100">
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>200 Menu Produk</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>20 Meja Kafe</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>10 Akun Staf / Kasir</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Laporan Penjualan Lengkap</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Enterprise Plan */}
                <div
                  onClick={() => setSelectedPlan('enterprise')}
                  className={`p-4 rounded-2xl border-2 transition cursor-pointer relative flex flex-col justify-between ${
                    selectedPlan === 'enterprise'
                      ? 'border-amber-600 bg-amber-50/40 shadow-md ring-2 ring-amber-500/20'
                      : 'border-gray-200 hover:border-amber-300'
                  }`}
                >
                  <div className="space-y-2">
                    <h4 className="font-extrabold text-gray-900 text-sm">Enterprise</h4>
                    <p className="text-[11px] text-gray-500">Kafe besar & multi-outlet</p>
                    <div className="text-base font-black text-amber-800">
                      {billingCycle === 'monthly' ? 'Rp 399.000' : 'Rp 3.990.000'}
                      <span className="text-[10px] font-normal text-gray-500">
                        {billingCycle === 'monthly' ? '/bln' : '/thn'}
                      </span>
                    </div>
                    <ul className="text-[11px] text-gray-600 space-y-1.5 pt-2 border-t border-gray-100">
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Unlimited Menu Produk</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Unlimited Meja Kafe</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Unlimited Akun Staf</span>
                      </li>
                      <li className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Prioritas 24/7 Support</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Midtrans Info Badge */}
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div>
                    <span className="font-bold text-gray-800">Pembayaran Otomatis</span>
                    <p className="text-[11px] text-gray-500">
                      Mendukung QRIS, GoPay, BCA/BNI/BRI/Mandiri VA, dan Kartu Kredit.
                    </p>
                  </div>
                </div>
                <div className="font-extrabold text-sm text-gray-900 shrink-0">
                  Total: {selectedPlan === 'starter' ? (billingCycle === 'monthly' ? 'Rp 99.000' : 'Rp 990.000') : selectedPlan === 'pro' ? (billingCycle === 'monthly' ? 'Rp 199.000' : 'Rp 1.990.000') : (billingCycle === 'monthly' ? 'Rp 399.000' : 'Rp 3.990.000')}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => setIsRenewalModalOpen(false)}
                className="px-4 py-2.5 text-gray-600 hover:text-gray-900 text-xs font-semibold rounded-xl hover:bg-gray-200 transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleCheckoutSubscription}
                disabled={submittingSubscription}
                className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center space-x-2 cursor-pointer"
              >
                {submittingSubscription ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Mempersiapkan...</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>Lanjutkan Pembayaran</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Load Midtrans Snap Script */}
      <Script
        src={process.env.NEXT_PUBLIC_MIDTRANS_SNAP_URL || 'https://app.sandbox.midtrans.com/snap/snap.js'}
        data-client-key={process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY || 'Mid-client-E5L8nRN8w6S_D9H7'}
        strategy="lazyOnload"
      />

      {/* Floating Animated Success Toast */}
      {showSavedToast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center space-x-3.5 bg-gray-950/95 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-emerald-500/40 backdrop-blur-md animate-in slide-in-from-bottom-5 fade-in duration-300">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5 animate-pulse text-emerald-400" />
          </div>
          <div>
            <p className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Perubahan Berhasil Disimpan</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            </p>
            <p className="text-[11px] text-gray-300">Pengaturan profil dan identitas kafe telah diperbarui.</p>
          </div>
        </div>
      )}
    </div>
  );
}

