'use client';

import React, { useEffect, useState } from 'react';
import StaffNavbar from '@/components/layout/StaffNavbar';
import { api } from '@/lib/api';
import { Table } from '@/types';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { QRCodeSVG } from 'qrcode.react';
import {
  QrCode,
  RotateCw,
  ExternalLink,
  Printer,
  Users,
  CheckCircle2,
  AlertCircle,
  X,
  Loader2,
  Plus,
  Trash2,
  RefreshCw,
} from 'lucide-react';
import Link from 'next/link';

export default function AdminTablesPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [tables, setTables] = useState<Table[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [qrModalTable, setQrModalTable] = useState<Table | null>(null);

  // Add Table Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTableNumber, setNewTableNumber] = useState('');
  const [newTableName, setNewTableName] = useState('');
  const [newCapacity, setNewCapacity] = useState<number>(4);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const fetchTables = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    try {
      const res = await api.get<Table[]>('/tables');
      if (res && Array.isArray(res)) {
        setTables(res);
      }
    } catch (e: any) {
      console.error('Error fetching tables:', e);
    } finally {
      setLoading(false);
      if (isManual) setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchTables();
  }, []);

  const handleAddTable = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTableNumber.trim()) {
      setFormError('Nomor meja harus diisi (contoh: T11)');
      return;
    }

    setIsSubmitting(true);
    setFormError('');
    try {
      await api.post<Table>('/tables', {
        tableNumber: newTableNumber.trim().toUpperCase(),
        name: newTableName.trim() || undefined,
        capacity: Number(newCapacity) || 4,
      });

      setIsAddModalOpen(false);
      setNewTableNumber('');
      setNewTableName('');
      setNewCapacity(4);
      setActionSuccess(`Meja ${newTableNumber.trim().toUpperCase()} berhasil ditambahkan!`);
      setTimeout(() => setActionSuccess(''), 4000);
      await fetchTables();
    } catch (err: any) {
      setFormError(err?.message || 'Gagal menambahkan meja');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteTable = async (table: Table) => {
    if (table.status !== 'AVAILABLE') {
      alert(`Meja ${table.tableNumber} tidak dapat dihapus karena sedang berstatus ${table.status}`);
      return;
    }

    if (!confirm(`Apakah Anda yakin ingin menghapus Meja ${table.tableNumber}?`)) {
      return;
    }

    try {
      await api.delete(`/tables/${table.id}`);
      setActionSuccess(`Meja ${table.tableNumber} berhasil dihapus.`);
      setTimeout(() => setActionSuccess(''), 4000);
      await fetchTables();
    } catch (err: any) {
      alert(err?.message || 'Gagal menghapus meja');
    }
  };

  const handleRegenerateQr = async (table: Table) => {
    if (!confirm(`Generate ulang token QR code untuk Meja ${table.tableNumber}? QR code lama tidak akan berlaku lagi.`)) {
      return;
    }

    try {
      await api.post(`/tables/${table.id}/regenerate-qr`, {});
      setActionSuccess(`QR code Meja ${table.tableNumber} berhasil diperbarui!`);
      setTimeout(() => setActionSuccess(''), 4000);
      await fetchTables();
    } catch (err: any) {
      alert(err?.message || 'Gagal memperbarui QR code');
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <StaffNavbar />

      {/* Header Toolbar */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-gray-900 tracking-tight">
                Manajemen Meja & QR Code
              </h1>
              <p className="text-xs text-gray-500">
                Tambah meja baru, kelola kapasitas, dan cetak QR Code pemesanan meja pelanggan
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => fetchTables(true)}
              disabled={refreshing}
              className="p-2 border border-gray-200 hover:bg-gray-50 text-gray-600 rounded-xl transition flex items-center space-x-1.5 text-xs font-semibold"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-amber-600' : ''}`} />
              <span>Perbarui</span>
            </button>

            <button
              onClick={() => {
                setFormError('');
                setIsAddModalOpen(true);
              }}
              className="py-2 px-3.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl transition flex items-center space-x-1.5 text-xs font-bold shadow-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Meja</span>
            </button>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {actionSuccess && (
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 pt-4">
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{actionSuccess}</span>
            </div>
            <button onClick={() => setActionSuccess('')} className="text-emerald-500 hover:text-emerald-700">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Tables Grid */}
      <main className="max-w-7xl mx-auto w-full p-4 sm:p-6 flex-1">
        {tables.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center max-w-md mx-auto my-12">
            <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <QrCode className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-gray-900 mb-1">Belum Ada Meja</h3>
            <p className="text-xs text-gray-500 mb-4">Tambahkan meja pertama Anda untuk membuat QR code meja pemesanan.</p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="py-2 px-4 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition inline-flex items-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Meja Pertama</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {tables.map((table) => {
              const qrToken = table.qrCode?.token || table.qrToken;
              const customerOrderUrl = qrToken ? `/order/${qrToken}` : null;

              return (
                <div
                  key={table.id}
                  className="bg-white rounded-2xl border border-gray-200/80 p-5 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4"
                >
                  {/* Table Header & Status */}
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs text-gray-400 font-bold uppercase tracking-wider block">
                        Meja Kafe
                      </span>
                      <h3 className="text-2xl font-black text-gray-900 tracking-tight">
                        {table.tableNumber}
                      </h3>
                      <div className="text-xs font-medium text-gray-600 mt-0.5">
                        {table.name || `Meja ${table.tableNumber}`}
                      </div>
                      <div className="flex items-center space-x-1 text-xs text-gray-500 mt-1">
                        <Users className="w-3.5 h-3.5" />
                        <span>Kapasitas {table.capacity} Orang</span>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-full ${
                        table.status === 'AVAILABLE'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : table.status === 'ORDERING'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}
                    >
                      {table.status}
                    </span>
                  </div>

                  {/* QR Code Preview Thumbnail */}
                  {qrToken ? (
                    <div
                      onClick={() => setQrModalTable(table)}
                      className="p-3 bg-gray-50 rounded-xl border border-dashed border-gray-200 flex flex-col items-center justify-center cursor-pointer hover:bg-amber-50/50 hover:border-amber-300 transition group"
                    >
                      <QRCodeSVG
                        value={table.qrCode?.url || `http://localhost:5001/order/${qrToken}`}
                        size={110}
                        level="M"
                        includeMargin={false}
                      />
                      <span className="text-[10px] font-semibold text-gray-400 group-hover:text-amber-700 mt-2 flex items-center gap-1">
                        <Printer className="w-3 h-3" /> Klik untuk perbesar / cetak
                      </span>
                    </div>
                  ) : (
                    <div className="p-4 bg-gray-50 rounded-xl text-center text-xs text-gray-400">
                      QR code belum di-generate
                    </div>
                  )}

                  {/* Quick Actions */}
                  <div className="pt-2 border-t border-gray-100 flex items-center gap-2">
                    {customerOrderUrl ? (
                      <Link
                        href={customerOrderUrl}
                        target="_blank"
                        className="flex-1 py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 shadow-xs"
                      >
                        <span>Buka Menu</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </Link>
                    ) : null}

                    <button
                      onClick={() => setQrModalTable(table)}
                      className="p-2 border border-gray-200 hover:bg-gray-100 rounded-xl text-gray-600 transition"
                      title="Cetak Kartu QR"
                    >
                      <QrCode className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleRegenerateQr(table)}
                      className="p-2 border border-gray-200 hover:bg-gray-100 rounded-xl text-gray-500 hover:text-amber-600 transition"
                      title="Perbarui QR Token"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleDeleteTable(table)}
                      className="p-2 border border-gray-200 hover:bg-red-50 hover:border-red-200 rounded-xl text-gray-400 hover:text-red-600 transition"
                      title="Hapus Meja"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Add Table Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center border-b border-gray-100 pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-gray-900">Tambah Meja Baru</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-semibold flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleAddTable} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  Nomor / Kode Meja <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: T11, VIP-01, OUT-02"
                  value={newTableNumber}
                  onChange={(e) => setNewTableNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 uppercase"
                />
                <span className="text-[11px] text-gray-400 mt-1 block">
                  Nomor meja harus unik di outlet ini.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  Nama Meja (Opsional)
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Meja 11 (Dekat Jendela)"
                  value={newTableName}
                  onChange={(e) => setNewTableName(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                  Kapasitas Kursi (Orang)
                </label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={newCapacity}
                  onChange={(e) => setNewCapacity(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="p-3 bg-amber-50/70 border border-amber-200/60 rounded-xl text-[11px] text-amber-800">
                💡 <strong>Info:</strong> QR Code unik untuk meja ini akan otomatis dibuat dan siap dicetak setelah meja disimpan.
              </div>

              <div className="flex gap-2 pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2.5 px-4 border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-2.5 px-4 bg-amber-600 hover:bg-amber-700 disabled:bg-amber-300 text-white rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 shadow-md"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Menyimpan...</span>
                    </>
                  ) : (
                    <span>Simpan Meja</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QR Code Printable Modal */}
      {qrModalTable && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center border-b border-gray-100 pb-3">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                Kartu QR Meja Kafe
              </span>
              <button
                onClick={() => setQrModalTable(null)}
                className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 bg-amber-50/50 border border-amber-100 rounded-2xl flex flex-col items-center space-y-3">
              <span className="text-xs font-bold text-amber-800 tracking-wider uppercase">
                Demo Cafe
              </span>
              <div className="text-3xl font-black text-gray-900 tracking-tight">
                MEJA {qrModalTable.tableNumber}
              </div>

              {(qrModalTable.qrCode?.token || qrModalTable.qrToken) && (
                <div className="p-3 bg-white rounded-xl shadow-xs border border-gray-200 my-2">
                  <QRCodeSVG
                    value={
                      qrModalTable.qrCode?.url ||
                      `http://localhost:5001/order/${qrModalTable.qrCode?.token || qrModalTable.qrToken}`
                    }
                    size={160}
                    level="H"
                  />
                </div>
              )}

              <p className="text-[11px] text-gray-500 max-w-[200px]">
                Pindai QR Code ini untuk memesan makanan dan minuman langsung dari meja Anda.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 px-4 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center justify-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak QR</span>
              </button>

              {(qrModalTable.qrCode?.token || qrModalTable.qrToken) && (
                <Link
                  href={`/order/${qrModalTable.qrCode?.token || qrModalTable.qrToken}`}
                  target="_blank"
                  className="flex-1 py-2.5 px-4 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
                >
                  <span>Tes Buka</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
