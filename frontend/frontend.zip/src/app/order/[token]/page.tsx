/* eslint-disable @next/next/no-img-element */
'use client';

import React, { useEffect, useState, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useCart } from '@/context/CartContext';
import { Category, Product } from '@/types';
import { formatRupiah, getImageUrl } from '@/lib/utils';
import ModifierModal from '@/components/customer/ModifierModal';
import CartDrawer from '@/components/customer/CartDrawer';
import CallWaiterModal from '@/components/customer/CallWaiterModal';
import {
  Coffee,
  ShoppingBag,
  Plus,
  AlertCircle,
  Search,
  Sparkles,
  Info,
  Loader2,
  CheckCircle2,
  X,
  Store,
  ChevronRight,
  ArrowRight,
  Flame,
  Utensils,
  Layers,
  HelpCircle,
  ConciergeBell,
} from 'lucide-react';

export default function CustomerOrderPage() {
  const params = useParams();
  const router = useRouter();
  const token = params?.token as string;

  const { items, setTableInfo, totalAmount } = useCart();

  const [tableData, setTableData] = useState<any>(null);
  const [outletData, setOutletData] = useState<any>(null);
  const [companyData, setCompanyData] = useState<any>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCallWaiterOpen, setIsCallWaiterOpen] = useState(false);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Read optional URL category parameter (e.g. from "Pesan Lagi" shortcuts)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const catParam = urlParams.get('cat');
      if (catParam) {
        setActiveCategory(catParam);
      }
      const searchParam = urlParams.get('q');
      if (searchParam) {
        setSearchQuery(searchParam);
      }
    }
  }, []);

  useEffect(() => {
    if (!token) return;

    const validateAndLoad = async () => {
      setLoading(true);
      setError(null);
      try {
        // 1. Validate QR Code token
        const validation = await api.get<any>(`/qr-codes/validate/${token}`);

        if (!validation.valid) {
          setError(validation.reason || 'QR Code meja tidak valid atau sudah kadaluarsa.');
          setLoading(false);
          return;
        }

        setTableData(validation.table);
        setOutletData(validation.outlet);
        setCompanyData(validation.company);

        // Save active table session into localStorage so customer never loses their table
        if (typeof window !== 'undefined') {
          localStorage.setItem('cafe_active_qr_token', token);
          if (validation.table?.tableNumber) {
            localStorage.setItem('cafe_active_table_number', String(validation.table.tableNumber));
          }
          if (validation.company?.name) {
            localStorage.setItem('cafe_active_cafe_name', validation.company.name);
          }
        }

        // Store table info in cart context
        setTableInfo(
          validation.table.id,
          validation.table.tableNumber,
          validation.outlet.id,
          Number(validation.outlet.taxRate) / 100 || 0.1,
          Number(validation.outlet.serviceCharge) / 100 || 0.05
        );

        // 2. Fetch Categories & Products
        const [catsRes, prodsRes] = await Promise.all([
          api.get<Category[]>('/categories').catch(() => []),
          api.get<Product[]>('/products').catch(() => []),
        ]);

        setCategories(catsRes || []);
        setProducts(prodsRes || []);
      } catch (err: any) {
        setError(err.message || 'Gagal memuat menu meja.');
      } finally {
        setLoading(false);
      }
    };

    validateAndLoad();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  // Filter products by category and search
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.isActive || p.status === 'INACTIVE') return false;
      const matchCategory =
        activeCategory === 'all' ||
        p.categoryId === activeCategory ||
        (p.category && p.category.name.toLowerCase() === activeCategory.toLowerCase());
      const matchSearch =
        searchQuery.trim() === '' ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.description && p.description.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCategory && matchSearch;
    });
  }, [products, activeCategory, searchQuery]);

  const totalCartCount = items.reduce((sum, item) => sum + item.quantity, 0);

  // Helper to count how many of this product are in cart
  const getProductCartCount = (productId: string) => {
    return items
      .filter((item) => item.product.id === productId)
      .reduce((sum, item) => sum + item.quantity, 0);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center p-4">
        <div className="w-14 h-14 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-xl shadow-amber-500/25 mb-4 animate-bounce">
          <Coffee className="w-7 h-7" />
        </div>
        <p className="text-sm font-bold text-stone-800">Menyiapkan Menu Meja...</p>
        <p className="text-xs text-stone-500 mt-1">Memverifikasi meja dan sinkronisasi harga kafe</p>
        <div className="flex items-center gap-1.5 mt-3 text-amber-600 text-xs font-semibold">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span>Memuat hidangan lezat...</span>
        </div>
      </div>
    );
  }

  if (error || !tableData) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
        <div className="bg-white max-w-sm w-full p-6 rounded-3xl border border-red-100 shadow-2xl text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto border border-red-100">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h2 className="text-lg font-black text-stone-900">QR Code Tidak Valid</h2>
          <p className="text-xs text-stone-600 leading-relaxed">
            {error || 'QR code meja tidak dapat ditemukan atau sudah dinonaktifkan oleh kasir.'}
          </p>
          <div className="p-3 bg-amber-50/80 rounded-2xl text-[11px] text-amber-900 text-left flex items-start gap-2.5 border border-amber-200/60">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />
            <span>Silakan tanyakan kasir atau pelayan untuk mendapatkan kode meja yang aktif.</span>
          </div>
        </div>
      </div>
    );
  }

  const cafeName = companyData?.name || outletData?.name || 'Cafe & Resto';
  const cafeLogo = companyData?.logoUrl || companyData?.logo;

  return (
    <div className="min-h-screen bg-stone-50/70 pb-36 text-stone-800">
      {/* Top Ambient Pro Accent */}
      <div className="h-[2.5px] w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 shadow-xs" />

      {/* Sticky Glassmorphic Header */}
      <header className="bg-white/92 backdrop-blur-xl border-b border-stone-200/80 sticky top-0 z-30 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.03)]">
        <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          {/* Brand Info */}
          <div className="flex items-center gap-3 min-w-0">
            {cafeLogo ? (
              <img
                src={getImageUrl(cafeLogo)}
                alt={cafeName}
                className="w-11 h-11 object-contain rounded-2xl bg-amber-50/80 p-1 border border-amber-200/80 shadow-xs shrink-0"
              />
            ) : (
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white font-bold text-base shadow-md shadow-amber-500/20 shrink-0">
                <Coffee className="w-6 h-6 drop-shadow-xs" />
              </div>
            )}

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h1 className="font-black text-sm text-stone-900 leading-tight truncate">
                  {cafeName}
                </h1>
                <span className="shrink-0 inline-flex items-center text-emerald-600">
                  <CheckCircle2 className="w-3.5 h-3.5 fill-emerald-100" />
                </span>
              </div>

              {/* Table Pill */}
              <div className="flex items-center gap-2 mt-0.5">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-black bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  <span>MEJA {tableData.tableNumber}</span>
                </div>
                {tableData.name && (
                  <span className="text-[11px] text-stone-500 font-medium truncate">
                    ({tableData.name})
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Cart Header Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            aria-label="Buka Keranjang"
            className="relative p-2.5 rounded-2xl bg-amber-50/80 text-amber-900 hover:bg-amber-100/90 border border-amber-200/80 transition-all duration-150 active:scale-95 cursor-pointer shrink-0"
          >
            <ShoppingBag className="w-5 h-5 text-amber-800" />
            {totalCartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-gradient-to-tr from-amber-600 to-orange-600 text-white font-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-in zoom-in-75">
                {totalCartCount}
              </span>
            )}
          </button>
        </div>

        {/* Welcome Pro Banner with Call Waiter Button */}
        <div className="max-w-xl mx-auto px-4 pb-2.5">
          <div className="bg-amber-50/70 border border-amber-200/70 rounded-2xl px-3.5 py-2 flex items-center justify-between text-xs text-amber-950 gap-2 shadow-2xs">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
              <span className="font-semibold text-[11px] sm:text-xs truncate">
                Pesan mandiri tanpa antre ke kasir
              </span>
            </div>

            <button
              type="button"
              onClick={() => setIsCallWaiterOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-amber-100 text-amber-950 border border-amber-300 font-bold text-[11px] shadow-xs transition active:scale-95 shrink-0 cursor-pointer"
            >
              <ConciergeBell className="w-3.5 h-3.5 text-amber-700" />
              <span>Panggil Pelayan</span>
            </button>
          </div>
        </div>

        {/* Search Input */}
        <div className="max-w-xl mx-auto px-4 pb-2.5">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Cari kopi, makanan, camilan, atau minuman..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-10 pr-9 py-2.5 bg-stone-100/80 border border-transparent rounded-2xl focus:bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-400/20 focus:outline-none transition shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600 p-0.5"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Categories Horizontal Scroll */}
        <div className="max-w-xl mx-auto px-4 flex gap-1.5 overflow-x-auto no-scrollbar pb-3">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-150 ${
              activeCategory === 'all'
                ? 'bg-amber-600 text-white shadow-sm shadow-amber-600/30 scale-[1.02]'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200/80'
            }`}
          >
            Semua Menu
          </button>
          {categories.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-150 ${
                  isActive
                    ? 'bg-amber-600 text-white shadow-sm shadow-amber-600/30 scale-[1.02]'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200/80'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Menu List */}
      <main className="max-w-xl mx-auto px-4 py-4 space-y-3">
        {/* Results Counter if searching */}
        {searchQuery.trim() !== '' && (
          <div className="flex items-center justify-between text-xs text-stone-500 px-1">
            <span>
              Hasil pencarian &quot;<strong>{searchQuery}</strong>&quot;
            </span>
            <span className="font-semibold text-amber-700">{filteredProducts.length} menu</span>
          </div>
        )}

        {filteredProducts.length === 0 ? (
          <div className="py-16 text-center text-stone-400 bg-white rounded-3xl border border-stone-200/80 p-8 shadow-xs">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3">
              <Coffee className="w-7 h-7 stroke-1" />
            </div>
            <p className="text-sm font-bold text-stone-700">Menu Tidak Ditemukan</p>
            <p className="text-xs text-stone-400 mt-1 max-w-xs mx-auto">
              {searchQuery
                ? 'Coba gunakan kata kunci lain atau pilih kategori di atas.'
                : 'Belum ada menu yang tersedia di kategori ini.'}
            </p>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="mt-4 px-4 py-2 rounded-xl bg-amber-600 text-white font-bold text-xs hover:bg-amber-700 transition"
              >
                Tampilkan Semua Menu
              </button>
            )}
          </div>
        ) : (
          filteredProducts.map((product) => {
            const hasCustomization =
              (product.variants && product.variants.length > 0) ||
              (product.modifiers && product.modifiers.length > 0);

            const isOutOfStock = product.status === 'OUT_OF_STOCK';
            const cartQty = getProductCartCount(product.id);

            return (
              <div
                key={product.id}
                onClick={() => !isOutOfStock && setSelectedProduct(product)}
                className={`p-3.5 bg-white rounded-3xl border transition-all duration-150 flex justify-between gap-3 relative ${
                  isOutOfStock
                    ? 'border-stone-200 opacity-60 cursor-not-allowed bg-stone-50/50'
                    : 'border-stone-200/80 hover:border-amber-300 hover:shadow-md cursor-pointer active:scale-[0.99] shadow-xs'
                }`}
              >
                {/* Left: Product Info */}
                <div className="flex-1 flex flex-col justify-between min-w-0 pr-1">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-sm text-stone-900 leading-snug">
                        {product.name}
                      </h3>
                      {hasCustomization && (
                        <span className="text-[9px] bg-amber-50 text-amber-800 font-bold px-1.5 py-0.5 rounded-md border border-amber-200/60">
                          Bisa Kustom
                        </span>
                      )}
                      {cartQty > 0 && (
                        <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded-md border border-emerald-200">
                          {cartQty} di keranjang
                        </span>
                      )}
                    </div>

                    {product.description && (
                      <p className="text-xs text-stone-500 line-clamp-2 mt-1 leading-relaxed">
                        {product.description}
                      </p>
                    )}
                  </div>

                  {/* Price & Action Button */}
                  <div className="mt-3 flex items-center justify-between pt-1">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-stone-400 font-medium leading-none">Harga</span>
                      <span className="font-black text-sm sm:text-base text-amber-800 leading-tight">
                        {formatRupiah(product.basePrice)}
                      </span>
                    </div>

                    {isOutOfStock ? (
                      <span className="text-xs font-bold text-red-500 bg-red-50 px-2.5 py-1 rounded-xl border border-red-100">
                        Habis
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedProduct(product);
                        }}
                        className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition active:scale-95 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{hasCustomization ? 'Pilih' : 'Tambah'}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Right: Product Image Thumbnail */}
                <div className="w-20 h-20 sm:w-24 sm:h-24 min-w-[5rem] min-h-[5rem] max-w-[5rem] max-h-[5rem] sm:min-w-[6rem] sm:min-h-[6rem] sm:max-w-[6rem] sm:max-h-[6rem] rounded-2xl bg-amber-50/60 border border-amber-100 shrink-0 flex items-center justify-center text-amber-700/60 overflow-hidden relative shadow-2xs">
                  {product.image ? (
                    <img
                      src={getImageUrl(product.image)}
                      alt={product.name}
                      className="w-full h-full object-cover rounded-2xl aspect-square"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <Coffee className="w-8 h-8 stroke-1 text-amber-500/50" />
                  )}
                </div>
              </div>
            );
          })
        )}
      </main>

      {/* Floating Bottom Cart Bar */}
      {totalCartCount > 0 && (
        <div className="fixed bottom-4 inset-x-0 z-40 max-w-lg mx-auto px-4 animate-in slide-in-from-bottom-4 duration-200">
          <div
            onClick={() => setIsCartOpen(true)}
            className="p-3.5 bg-stone-950/95 backdrop-blur-xl text-white rounded-3xl shadow-2xl border border-stone-800 flex items-center justify-between cursor-pointer hover:bg-stone-900 transition transform hover:-translate-y-0.5 active:scale-[0.99]"
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center font-black text-sm text-white shadow-md shadow-amber-500/30 shrink-0">
                {totalCartCount}
              </div>
              <div>
                <div className="text-[11px] text-stone-400 flex items-center gap-1">
                  <span>Meja {tableData.tableNumber}</span>
                  <span>•</span>
                  <span>{totalCartCount} item siap dipesan</span>
                </div>
                <div className="font-black text-base text-amber-400 leading-tight">
                  {formatRupiah(totalAmount)}
                </div>
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white px-4 py-2.5 rounded-2xl shadow-md transition shrink-0">
              <span>Lihat Pesanan</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      )}

      {/* Modal Customization (Variants & Modifiers) */}
      <ModifierModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />

      {/* Drawer Cart & Checkout */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        company={companyData}
        tableToken={token}
      />

      {/* Modal Panggil Pelayan */}
      <CallWaiterModal
        isOpen={isCallWaiterOpen}
        onClose={() => setIsCallWaiterOpen(false)}
        tableToken={token}
        tableId={tableData?.id}
        tableNumber={tableData?.tableNumber}
      />
    </div>
  );
}
