'use client';

import React, { useEffect, useState } from 'react';
import StaffNavbar from '@/components/layout/StaffNavbar';
import { api } from '@/lib/api';
import { Order } from '@/types';
import { formatTime } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import {
  UtensilsCrossed,
  ConciergeBell,
  Clock,
  RotateCw,
  Check,
  Play,
  Loader2,
  Volume2,
  VolumeX,
  Bell,
} from 'lucide-react';
import { playNotificationSound, isAudioMuted, setAudioMuted, testAudioNotification } from '@/lib/audio';

export default function KitchenPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [audioMuted, setAudioMutedState] = useState(false);
  const [newOrderAlert, setNewOrderAlert] = useState<string | null>(null);

  const prevOrderIdsRef = React.useRef<Set<string>>(new Set());
  const isInitialLoadRef = React.useRef(true);

  useEffect(() => {
    setAudioMutedState(isAudioMuted());
  }, []);

  const toggleMute = () => {
    const next = !audioMuted;
    setAudioMutedState(next);
    setAudioMuted(next);
    if (!next) {
      testAudioNotification('order');
    }
  };

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const fetchKitchenOrders = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    try {
      // Fetch orders for kitchen: PAID, CONFIRMED and PREPARING
      const res = await api.get<Order[]>('/orders');
      if (res && Array.isArray(res)) {
        const kitchenQueue = res.filter((o) => ['PAID', 'CONFIRMED', 'PREPARING'].includes(o.status));

        if (!isInitialLoadRef.current) {
          const newOrders = kitchenQueue.filter((o) => !prevOrderIdsRef.current.has(o.id));
          if (newOrders.length > 0) {
            playNotificationSound('order');
            const latest = newOrders[0];
            const tableName = latest.table?.tableNumber ? `Meja ${latest.table.tableNumber}` : `#${latest.orderNumber}`;
            setNewOrderAlert(`🔔 Ada ${newOrders.length} pesanan baru masuk! (${tableName})`);
            setTimeout(() => setNewOrderAlert(null), 5000);
          }
        } else {
          isInitialLoadRef.current = false;
        }

        prevOrderIdsRef.current = new Set(kitchenQueue.map((o) => o.id));
        setOrders(kitchenQueue);
      }
    } catch (e) {
      console.error('Error fetching kitchen orders:', e);
    } finally {
      setLoading(false);
      if (isManual) setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchKitchenOrders();
    const interval = setInterval(() => {
      fetchKitchenOrders();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleStartPreparing = async (orderId: string) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status: 'PREPARING' });
      fetchKitchenOrders();
    } catch (e: any) {
      alert(e.message || 'Gagal mengubah status');
    }
  };

  const handleMarkReady = async (orderId: string) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status: 'READY' });
      fetchKitchenOrders();
    } catch (e: any) {
      alert(e.message || 'Gagal mengubah status');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-900 text-stone-100 flex flex-col">
      <StaffNavbar />

      {/* Header Toolbar */}
      <div className="bg-stone-800/80 border-b border-stone-700 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <UtensilsCrossed className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight">Kitchen / Bar Display</h1>
            <p className="text-xs text-stone-400">Antrean pembuatan makanan dan minuman</p>
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Audio Controls */}
          <button
            type="button"
            onClick={toggleMute}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
              audioMuted
                ? 'bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/30'
            }`}
            title={audioMuted ? 'Suara Dinonaktifkan (Klik untuk bunyikan)' : 'Suara Aktif (Klik untuk mute)'}
          >
            {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{audioMuted ? 'Suara Off' : 'Suara On'}</span>
          </button>

          <button
            type="button"
            onClick={() => testAudioNotification('order')}
            className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-stone-700 hover:bg-stone-600 text-stone-300 transition border border-stone-600"
            title="Tes Suara Notifikasi"
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Tes Ting</span>
          </button>

          <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
            {orders.length} Tiket Antre
          </span>

          <button
            onClick={() => fetchKitchenOrders(true)}
            disabled={refreshing}
            className="p-2 bg-stone-700 hover:bg-stone-600 rounded-xl transition text-stone-300"
            title="Refresh"
          >
            <RotateCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-amber-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Floating Real-time Order Arrival Banner */}
      {newOrderAlert && (
        <div className="bg-amber-500 text-stone-950 px-6 py-2.5 font-black text-sm flex items-center justify-between shadow-lg animate-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-stone-950 animate-ping" />
            <span>{newOrderAlert}</span>
          </div>
          <button
            onClick={() => setNewOrderAlert(null)}
            className="text-xs font-bold px-2 py-0.5 bg-stone-950/20 hover:bg-stone-950/40 rounded-lg transition"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Order Tickets Grid */}
      <div className="flex-1 p-6 overflow-y-auto">
        {orders.length === 0 ? (
          <div className="py-24 text-center text-stone-500">
            <UtensilsCrossed className="w-16 h-16 mx-auto mb-3 opacity-20" />
            <h3 className="text-lg font-bold text-stone-400">Semua Pesanan Selesai!</h3>
            <p className="text-sm text-stone-500 mt-1">Tidak ada antrean pesanan yang perlu dimasak saat ini.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {orders.map((order) => {
              const isPreparing = order.status === 'PREPARING';

              return (
                <div
                  key={order.id}
                  className={`rounded-2xl border flex flex-col justify-between overflow-hidden shadow-lg transition ${
                    isPreparing
                      ? 'bg-stone-800 border-amber-500/50 ring-2 ring-amber-500/20'
                      : 'bg-stone-800/80 border-stone-700'
                  }`}
                >
                  {/* Card Header */}
                  <div
                    className={`px-4 py-3 border-b flex items-center justify-between ${
                      isPreparing
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                        : 'bg-stone-700/50 border-stone-700 text-stone-300'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-black font-mono">#{order.orderNumber}</div>
                      <div className="text-xs font-bold text-stone-200">
                        {order.table?.tableNumber ? `MEJA ${order.table.tableNumber}` : 'TAKEAWAY'}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-medium flex items-center space-x-1 justify-end">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{formatTime(order.createdAt)}</span>
                      </div>
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                          isPreparing
                            ? 'bg-amber-500 text-stone-900'
                            : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {isPreparing ? 'Sedang Dimasak' : 'Menunggu'}
                      </span>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="p-4 space-y-3 flex-1 overflow-y-auto">
                    {order.customerNotes && (
                      <div className="p-2.5 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-300 font-medium">
                        Catatan: &quot;{order.customerNotes}&quot;
                      </div>
                    )}

                    <div className="space-y-2.5">
                      {order.items.map((item) => (
                        <div key={item.id} className="border-b border-stone-700/60 pb-2.5 last:border-0 last:pb-0">
                          <div className="flex items-start space-x-2">
                            <span className="w-6 h-6 rounded-md bg-stone-700 font-bold text-xs flex items-center justify-center shrink-0 text-amber-400">
                              {item.quantity}x
                            </span>
                            <div className="flex-1">
                              <span className="font-bold text-sm text-stone-100 block">
                                {item.productName}
                              </span>
                              {item.variantName && (
                                <span className="text-xs text-stone-400 block font-medium">
                                  Varian: {item.variantName}
                                </span>
                              )}
                              {item.modifiers && item.modifiers.length > 0 && (
                                <div className="text-xs text-amber-400/90 font-medium mt-0.5">
                                  {item.modifiers.map((m) => m.modifierOptionName).join(', ')}
                                </div>
                              )}
                              {item.notes && (
                                <div className="text-xs text-yellow-300 italic mt-0.5">
                                  &quot;{item.notes}&quot;
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Card Actions Footer */}
                  <div className="p-3 border-t border-stone-700/80 bg-stone-900/50">
                    {!isPreparing ? (
                      <button
                        onClick={() => handleStartPreparing(order.id)}
                        className="w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center space-x-1.5"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Mulai Memasak</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleMarkReady(order.id)}
                        className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center space-x-1.5"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Selesai / Siap Diantar</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

