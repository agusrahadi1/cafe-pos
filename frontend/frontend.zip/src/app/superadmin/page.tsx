'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/lib/api';
import SuperadminNavbar from '@/components/layout/SuperadminNavbar';
import { formatRupiah } from '@/lib/utils';
import { PlatformAnalytics, Tenant } from '@/types';
import {
  Building2,
  Users,
  CreditCard,
  TrendingUp,
  ShoppingBag,
  ShieldCheck,
  AlertTriangle,
  RotateCw,
  Plus,
  ArrowUpRight,
  Loader2,
  ExternalLink,
} from 'lucide-react';

export default function SuperadminDashboardPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [analytics, setAnalytics] = useState<PlatformAnalytics | null>(null);
  const [recentTenants, setRecentTenants] = useState<Tenant[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push('/superadmin/login');
      } else if (user.role !== 'SUPERADMIN') {
        router.push('/login');
      }
    }
  }, [user, authLoading, router]);

  const fetchData = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    try {
      const [analyticsRes, tenantsRes] = await Promise.all([
        api.get<PlatformAnalytics>('/superadmin/analytics'),
        api.get<Tenant[]>('/superadmin/tenants'),
      ]);
      if (analyticsRes) setAnalytics(analyticsRes);
      if (tenantsRes) setRecentTenants(tenantsRes.slice(0, 5));
    } catch (e) {
      console.error('Error fetching superadmin data:', e);
    } finally {
      setLoading(false);
      if (isManual) setRefreshing(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'SUPERADMIN') {
      fetchData();
    }
  }, [user]);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <SuperadminNavbar />

      {/* Header Toolbar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
              <span>Platform Analytics & SaaS Overview</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Monitoring performa global tenan kafe, langganan SaaS, dan volume transaksi
            </p>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              onClick={() => fetchData(true)}
              disabled={refreshing}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl transition flex items-center space-x-1.5 text-xs font-semibold"
            >
              <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-indigo-400' : ''}`} />
              <span>Perbarui</span>
            </button>

            <a
              href="/superadmin/tenants"
              className="py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition flex items-center space-x-1.5 text-xs font-bold shadow-lg shadow-indigo-600/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Daftarkan Tenan Baru</span>
            </a>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-6 flex-1">
        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Total Tenants */}
          <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Total Tenan Terdaftar
              </span>
              <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                <Building2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-white tracking-tight">
              {analytics?.tenants?.total || 0}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 pt-2 border-t border-slate-800">
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                ● {analytics?.tenants?.active || 0} Aktif
              </span>
              <span>•</span>
              <span className="text-rose-400 font-bold">
                {analytics?.tenants?.suspended || 0} Ditangguhkan
              </span>
            </div>
          </div>

          {/* Card 2: Platform MRR */}
          <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Monthly Recurring (MRR)
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <CreditCard className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-emerald-400 tracking-tight">
              {formatRupiah(analytics?.subscriptions?.mrr || 0)}
            </div>
            <div className="text-xs text-slate-400 pt-2 border-t border-slate-800">
              ARR: <strong className="text-slate-200">{formatRupiah(analytics?.subscriptions?.arr || 0)}</strong>
            </div>
          </div>

          {/* Card 3: Ecosystem Orders */}
          <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Total Transaksi Kafe
              </span>
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-white tracking-tight">
              {analytics?.ecosystem?.totalOrders || 0}
            </div>
            <div className="text-xs text-slate-400 pt-2 border-t border-slate-800">
              Dari seluruh gerai tenan terdaftar
            </div>
          </div>

          {/* Card 4: Ecosystem GMV */}
          <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Akumulasi GMV Ekosistem
              </span>
              <div className="w-8 h-8 rounded-lg bg-violet-500/10 text-violet-400 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-violet-400 tracking-tight">
              {formatRupiah(analytics?.ecosystem?.totalGmv || 0)}
            </div>
            <div className="text-xs text-slate-400 pt-2 border-t border-slate-800">
              Volume penjualan gabungan tenan
            </div>
          </div>
        </div>

        {/* Action Shortcuts */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <a
            href="/superadmin/tenants"
            className="group bg-slate-900 hover:bg-slate-850 border border-slate-800 p-5 rounded-2xl transition flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                <Building2 className="w-4 h-4" />
                <span>Kelola & Pendaftaran Tenan</span>
              </div>
              <p className="text-xs text-slate-400">
                Pencarian, aktivasi, penangguhan (suspend), dan reset password owner.
              </p>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-500 group-hover:text-indigo-400 transition" />
          </a>

          <a
            href="/superadmin/plans"
            className="group bg-slate-900 hover:bg-slate-850 border border-slate-800 p-5 rounded-2xl transition flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CreditCard className="w-4 h-4" />
                <span>Paket Langganan & Kuota</span>
              </div>
              <p className="text-xs text-slate-400">
                Atur paket Starter, Pro, Enterprise serta batas kuota menu & staf.
              </p>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-500 group-hover:text-emerald-400 transition" />
          </a>

          <a
            href="/superadmin/subscriptions"
            className="group bg-slate-900 hover:bg-slate-850 border border-slate-800 p-5 rounded-2xl transition flex items-center justify-between"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <ShieldCheck className="w-4 h-4" />
                <span>Masa Aktif & Perpanjangan</span>
              </div>
              <p className="text-xs text-slate-400">
                Pantau masa aktif paket dan lakukan perpanjangan langganan tenan.
              </p>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition" />
          </a>
        </div>

        {/* Recent Tenants Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-indigo-400" />
              <span>Daftar Tenan Kafe Terdaftar</span>
            </h3>
            <a href="/superadmin/tenants" className="text-xs text-indigo-400 hover:underline font-semibold">
              Lihat Semua Tenan →
            </a>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-800/60 uppercase font-bold text-[10px] text-slate-400 tracking-wider">
                <tr>
                  <th className="p-3 rounded-l-xl">Nama Kafe & Slug URL</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Paket Aktif</th>
                  <th className="p-3">Akun Owner</th>
                  <th className="p-3">Menu & Staf</th>
                  <th className="p-3 rounded-r-xl text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentTenants.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-800/30 transition">
                    <td className="p-3">
                      <div>
                        <div className="font-bold text-white text-sm">{t.name}</div>
                        <a
                          href={`/${t.slug}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] text-indigo-400 hover:underline flex items-center gap-1 mt-0.5"
                        >
                          <span>/{t.slug}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                    </td>
                    <td className="p-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          t.status === 'ACTIVE'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : t.status === 'SUSPENDED'
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className="font-bold text-slate-200">
                        {t.activeSubscription?.plan?.name || 'Starter'}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="text-slate-300 font-medium">{t.owner?.email || t.email || '-'}</div>
                      <div className="text-[10px] text-slate-500">{t.owner?.fullName || '-'}</div>
                    </td>
                    <td className="p-3">
                      <span className="text-slate-300 font-medium">
                        {t.counts?.products || 0} Menu • {t.counts?.staff || 0} Staf
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <a
                        href={`/${t.slug}/pos`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition text-xs font-semibold inline-flex items-center gap-1"
                      >
                        <span>Buka POS</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}

