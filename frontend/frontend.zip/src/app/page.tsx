'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';
import { Coffee, QrCode, LayoutDashboard, UtensilsCrossed, ConciergeBell, ArrowRight, CheckCircle2 } from 'lucide-react';

export default function HomePage() {
  const [tables, setTables] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Attempt to fetch public tables to let user easily test QR ordering
    const fetchTables = async () => {
      try {
        // Backend tables might require auth or we can use the seeded QR token
        // Let's fetch tables or show mock direct links
        const res = await api.get<any[]>('/tables').catch(() => null);
        if (res && Array.isArray(res)) {
          setTables(res);
        }
      } catch {
      } finally {
        setLoading(false);
      }
    };
    fetchTables();
  }, []);

  return (
    <main className="min-h-screen bg-gradient-to-br from-amber-50/60 via-orange-50/30 to-stone-100 flex flex-col justify-between">
      {/* Top Banner */}
      <header className="border-b border-amber-100/80 bg-white/70 backdrop-blur-md sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-md shadow-amber-600/20">
              <Coffee className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-gray-900 text-lg tracking-tight">Cafe POS</span>
              <span className="text-xs bg-amber-100 text-amber-800 font-medium px-2 py-0.5 rounded-full ml-2">v1.0 Live PRO</span>
            </div>
          </div>

          <div className="flex items-center space-x-3">

            <Link
              href="/demo-cafe"
              className="inline-flex items-center space-x-1.5 text-xs sm:text-sm font-semibold text-amber-800 bg-amber-100/80 hover:bg-amber-200/80 px-3.5 py-2 rounded-xl transition"
            >
              <span>Demo Cafe Portal</span>
            </Link>
            <Link
              href="/pos"
              className="inline-flex items-center space-x-2 text-xs sm:text-sm font-semibold bg-amber-600 text-white hover:bg-amber-700 px-4 py-2 rounded-xl shadow-sm transition"
            >
              <span>Buka POS Kasir</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 flex-1 flex flex-col justify-center">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 tracking-tight leading-tight">
            Sistem Kasir & <span className="text-amber-600">QR Table Ordering</span> Terintegrasi
          </h1>
          <p className="mt-4 text-base sm:text-lg text-gray-600 leading-relaxed">
            Satu transaksi terpadu menghubungkan langsung pemesanan pelanggan dari meja ke Kasir, Dapur (Kitchen Display), dan Pelayan (Waiter).
          </p>
        </div>


        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full">
          {/* Card 1: Customer QR Ordering */}
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center mb-4">
                <QrCode className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">QR Table Ordering</h3>
              <p className="text-sm text-gray-500 mt-2">
                Simulasi pemesanan pelanggan dengan scan QR code meja. Pilih varian, topping, dan checkout seketika.
              </p>
              <ul className="mt-4 space-y-2 text-xs text-gray-600">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Varian (Hot/Iced) & Modifiers (Sugar/Ice)
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Metode Bayar QRIS & Tunai di Kasir
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Pelacakan Status Real-time
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-50">
              <Link
                href="/admin/tables"
                className="w-full inline-flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl text-sm font-semibold bg-orange-50 text-orange-700 hover:bg-orange-100 transition"
              >
                <span>Buka Simulasi Meja (QR)</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Card 2: Cashier POS */}
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mb-4">
                <LayoutDashboard className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">POS & Order Kanban</h3>
              <p className="text-sm text-gray-500 mt-2">
                Dashboard monitoring order terpadu berbasis Kanban board: Baru, Dimasak, Siap Antar, hingga Selesai.
              </p>
              <ul className="mt-4 space-y-2 text-xs text-gray-600">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Input Order Manual Walk-in
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Konfirmasi & Batalkan Pesanan
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Sinkronisasi Status Otomatis
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-50">
              <Link
                href="/pos"
                className="w-full inline-flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl text-sm font-semibold bg-amber-50 text-amber-700 hover:bg-amber-100 transition"
              >
                <span>Buka Dashboard Kasir</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Card 3: Kitchen & Waiter */}
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center mb-4">
                <UtensilsCrossed className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Dapur & Pelayan</h3>
              <p className="text-sm text-gray-500 mt-2">
                Antarmuka khusus koki (Kitchen Display) dan pramusaji (Waiter Delivery) untuk alur persiapan pesanan yang cepat.
              </p>
              <ul className="mt-4 space-y-2 text-xs text-gray-600">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Kitchen: Status Sedang Dibuat & Siap
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Waiter: Notifikasi Pesanan Siap Antar Meja
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Status Selesai Antar (Delivered)
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-50 flex gap-2">
              <Link
                href="/kitchen"
                className="flex-1 inline-flex items-center justify-center py-2.5 px-3 rounded-xl text-xs font-semibold bg-stone-100 text-stone-700 hover:bg-stone-200 transition"
              >
                <span>Dapur</span>
              </Link>
              <Link
                href="/waiter"
                className="flex-1 inline-flex items-center justify-center py-2.5 px-3 rounded-xl text-xs font-semibold bg-stone-100 text-stone-700 hover:bg-stone-200 transition"
              >
                <span>Pelayan</span>
              </Link>
            </div>
          </div>

          {/* Card 4: Menu & Harga */}
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-4">
                <Coffee className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Kelola Menu & Harga</h3>
              <p className="text-sm text-gray-500 mt-2">
                Tambah menu baru, atur harga jual dan harga modal, serta kelola ketersediaan stok produk.
              </p>
              <ul className="mt-4 space-y-2 text-xs text-gray-600">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Tambah / Edit / Hapus Menu
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Atur Harga Jual & Harga Modal
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Toggle Stok: Tersedia / Habis
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-50">
              <Link
                href="/admin/menu"
                className="w-full inline-flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl text-sm font-semibold bg-amber-50 text-amber-700 hover:bg-amber-100 transition"
              >
                <span>Kelola Menu & Harga</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white/50 text-center py-6 text-xs text-gray-500">
        Cafe POS & QR Ordering System • Multi-role Operational Platform • 2026 By PT ADNAN BERKAH SEJAHTERA
      </footer>
    </main>
  );
}
