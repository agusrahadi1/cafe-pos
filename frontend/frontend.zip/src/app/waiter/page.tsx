'use client';

import React, { useEffect, useState, useRef } from 'react';
import StaffNavbar from '@/components/layout/StaffNavbar';
import { api } from '@/lib/api';
import { Order } from '@/types';
import { formatTime } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import {
  ConciergeBell,
  CheckCheck,
  RotateCw,
  Clock,
  Check,
  Send,
  Loader2,
  Volume2,
  VolumeX,
  Bell,
  Utensils,
  Receipt,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { playNotificationSound, isAudioMuted, setAudioMuted, testAudioNotification } from '@/lib/audio';

interface WaiterCall {
  id: string;
  tableId: string;
  tableNumber: string;
  tableName?: string;
  type: string;
  notes?: string;
  createdAt: string;
  status: 'PENDING' | 'RESOLVED';
}

export default function WaiterPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [orders, setOrders] = useState<Order[]>([]);
  const [waiterCalls, setWaiterCalls] = useState<WaiterCall[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [audioMuted, setAudioMutedState] = useState(false);

  const prevReadyOrderIdsRef = useRef<Set<string>>(new Set());
  const prevWaiterCallIdsRef = useRef<Set<string>>(new Set());
  const isInitialLoadRef = useRef(true);

  useEffect(() => {
    setAudioMutedState(isAudioMuted());
  }, []);

  const toggleMute = () => {
    const next = !audioMuted;
    setAudioMutedState(next);
    setAudioMuted(next);
    if (!next) {
      testAudioNotification('bell');
    }
  };

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  const fetchWaiterData = async (isManual = false) => {
    if (isManual) setRefreshing(true);
    try {
      const [ordersRes, callsRes] = await Promise.all([
        api.get<Order[]>('/orders').catch(() => []),
        api.get<WaiterCall[]>('/tables/waiter-calls').catch(() => []),
      ]);

      if (Array.isArray(ordersRes)) {
        const waiterQueue = ordersRes.filter((o) => ['READY', 'OUT_FOR_DELIVERY'].includes(o.status));

        if (!isInitialLoadRef.current) {
          // Check for newly ready orders
          const newReady = waiterQueue.filter(
            (o) => o.status === 'READY' && !prevReadyOrderIdsRef.current.has(o.id)
          );
          if (newReady.length > 0) {
            playNotificationSound('ready');
          }
        }

        prevReadyOrderIdsRef.current = new Set(waiterQueue.map((o) => o.id));
        setOrders(waiterQueue);
      }

      if (Array.isArray(callsRes)) {
        if (!isInitialLoadRef.current) {
          // Check for new customer calls
          const newCalls = callsRes.filter((c) => !prevWaiterCallIdsRef.current.has(c.id));
          if (newCalls.length > 0) {
            playNotificationSound('bell');
          }
        }

        prevWaiterCallIdsRef.current = new Set(callsRes.map((c) => c.id));
        setWaiterCalls(callsRes);
      }

      isInitialLoadRef.current = false;
    } catch (e) {
      console.error('Error fetching waiter data:', e);
    } finally {
      setLoading(false);
      if (isManual) setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchWaiterData();
    const interval = setInterval(() => {
      fetchWaiterData();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handlePickUp = async (orderId: string) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status: 'OUT_FOR_DELIVERY' });
      fetchWaiterData();
    } catch (e: any) {
      alert(e.message || 'Gagal mengubah status');
    }
  };

  const handleDelivered = async (orderId: string) => {
    try {
      await api.put(`/orders/${orderId}/status`, { status: 'DELIVERED' });
      fetchWaiterData();
    } catch (e: any) {
      alert(e.message || 'Gagal mengubah status');
    }
  };

  const handleResolveWaiterCall = async (callId: string) => {
    try {
      await api.put(`/tables/waiter-calls/${callId}/resolve`);
      setWaiterCalls((prev) => prev.filter((c) => c.id !== callId));
    } catch (e: any) {
      alert(e.message || 'Gagal menyelesaikan panggilan meja');
    }
  };

  const getCallTypeLabel = (type: string) => {
    switch (type) {
      case 'REQUEST_BILL':
        return { label: 'Minta Tagihan / Bill', icon: Receipt, color: 'bg-emerald-50 text-emerald-800 border-emerald-200' };
      case 'NEED_UTENSILS':
        return { label: 'Alat Makan & Tisu', icon: Utensils, color: 'bg-blue-50 text-blue-800 border-blue-200' };
      case 'CUSTOM':
        return { label: 'Pesan Khusus', icon: MessageSquare, color: 'bg-amber-50 text-amber-800 border-amber-200' };
      default:
        return { label: 'Panggil Pelayan', icon: ConciergeBell, color: 'bg-purple-50 text-purple-800 border-purple-200' };
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col text-stone-800">
      <StaffNavbar />

      {/* Header Toolbar */}
      <div className="bg-white border-b border-stone-200 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center shadow-xs">
            <ConciergeBell className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black text-stone-900 leading-tight">
                Layar Pelayan (Waiter)
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-purple-100 text-purple-800 border border-purple-200">
                Live Alert
              </span>
            </div>
            <p className="text-xs text-stone-500">Panggilan meja & pesanan siap saji</p>
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Audio Controls */}
          <button
            type="button"
            onClick={toggleMute}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
              audioMuted
                ? 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100'
                : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
            }`}
            title={audioMuted ? 'Suara Bel Mati' : 'Suara Bel Aktif'}
          >
            {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{audioMuted ? 'Suara Off' : 'Suara On'}</span>
          </button>

          <button
            type="button"
            onClick={() => testAudioNotification('bell')}
            className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-stone-50 hover:bg-stone-100 text-stone-700 transition border border-stone-200"
            title="Tes Suara Bel Pelayan"
          >
            <Bell className="w-3.5 h-3.5 text-purple-600" />
            <span>Tes Bel</span>
          </button>

          <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
            {orders.length} Siap Antar
          </span>

          <button
            onClick={() => fetchWaiterData(true)}
            disabled={refreshing}
            className="p-2 border border-stone-200 hover:bg-stone-50 text-stone-600 rounded-xl transition"
            title="Refresh"
          >
            <RotateCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-purple-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto w-full p-4 sm:p-6 space-y-6 flex-1">
        {/* ========================================================================= */}
        {/* SECTION 1: PANGGILAN MEJA DARI PELANGGAN (CALL WAITER QUEUE)             */}
        {/* ========================================================================= */}
        {waiterCalls.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <h2 className="font-black text-sm text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Bell className="w-4 h-4 text-purple-600" />
                  <span>Panggilan Meja Aktif ({waiterCalls.length})</span>
                </h2>
              </div>
              <span className="text-[11px] text-stone-500">
                Pelanggan membutuhkan bantuan di meja
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {waiterCalls.map((call) => {
                const callConfig = getCallTypeLabel(call.type);
                const Icon = callConfig.icon;

                return (
                  <div
                    key={call.id}
                    className="p-4 bg-white rounded-3xl border-2 border-purple-300 shadow-md flex flex-col justify-between space-y-3 relative overflow-hidden animate-in zoom-in-95 duration-150"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-10 h-10 rounded-2xl bg-purple-600 text-white flex items-center justify-center font-black text-sm shadow-xs">
                          {call.tableNumber}
                        </div>
                        <div>
                          <div className="text-xs font-black text-stone-900">
                            MEJA {call.tableNumber}
                          </div>
                          {call.tableName && (
                            <div className="text-[11px] text-stone-400">({call.tableName})</div>
                          )}
                        </div>
                      </div>

                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase border ${callConfig.color}`}
                      >
                        <Icon className="w-3 h-3" />
                        <span>{callConfig.label}</span>
                      </span>
                    </div>

                    {call.notes && (
                      <p className="text-xs text-stone-700 bg-stone-50 p-2.5 rounded-xl border border-stone-200/80 italic">
                        &quot;{call.notes}&quot;
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-1 border-t border-stone-100">
                      <span className="text-[10px] text-stone-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTime(call.createdAt)}
                      </span>

                      <button
                        type="button"
                        onClick={() => handleResolveWaiterCall(call.id)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition active:scale-95 flex items-center gap-1 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Selesai Dilayani</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SECTION 2: PESANAN SIAP ANTAR (READY / OUT_FOR_DELIVERY)                  */}
        {/* ========================================================================= */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-black text-sm text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
              <ConciergeBell className="w-4 h-4 text-purple-600" />
              <span>Antrean Makanan Siap Antar ({orders.length})</span>
            </h2>
            <span className="text-[11px] text-stone-500">
              Makanan & minuman yang telah selesai dimasak oleh dapur
            </span>
          </div>

          {orders.length === 0 ? (
            <div className="py-20 text-center text-stone-400 bg-white rounded-3xl border border-stone-200/80 shadow-xs">
              <ConciergeBell className="w-14 h-14 mx-auto mb-2 opacity-25 stroke-1 text-purple-600" />
              <h3 className="text-base font-bold text-stone-700">Tidak Ada Pesanan Siap Diantar</h3>
              <p className="text-xs text-stone-400 mt-1 max-w-sm mx-auto">
                Semua pesanan saat ini sedang diproses oleh dapur atau sudah diantarkan ke meja pelanggan.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {orders.map((order) => {
                const isOut = order.status === 'OUT_FOR_DELIVERY';

                return (
                  <div
                    key={order.id}
                    className={`bg-white rounded-3xl border p-5 shadow-xs flex flex-col justify-between space-y-4 transition ${
                      isOut ? 'border-amber-300 ring-2 ring-amber-100' : 'border-purple-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="px-3 py-1 bg-purple-600 text-white font-black text-xs rounded-xl shadow-xs">
                            {order.table?.tableNumber ? `Meja ${order.table.tableNumber}` : 'Takeaway'}
                          </span>
                          <span className="text-xs font-mono text-stone-500">#{order.orderNumber}</span>
                        </div>
                        <div className="text-xs text-stone-400 mt-1 flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{formatTime(order.createdAt)}</span>
                          {order.customerName && (
                            <>
                              <span>•</span>
                              <span className="font-semibold text-stone-700">{order.customerName}</span>
                            </>
                          )}
                        </div>
                      </div>

                      <span
                        className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                          isOut ? 'bg-amber-100 text-amber-800' : 'bg-purple-100 text-purple-800'
                        }`}
                      >
                        {isOut ? 'Sedang Diantar' : 'Siap Antar'}
                      </span>
                    </div>

                    {/* Items List */}
                    <div className="bg-stone-50 p-3 rounded-2xl space-y-2 border border-stone-100">
                      <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">
                        Menu yang Harus Diantar:
                      </div>
                      <div className="divide-y divide-stone-200/60 text-xs">
                        {order.items.map((item) => (
                          <div key={item.id} className="py-1.5 flex justify-between items-start">
                            <div>
                              <span className="font-bold text-stone-900">
                                {item.quantity}x {item.productName}
                              </span>
                              {item.variantName && (
                                <span className="text-stone-500 ml-1">({item.variantName})</span>
                              )}
                              {item.modifiers && item.modifiers.length > 0 && (
                                <div className="text-[10px] text-stone-400">
                                  {item.modifiers.map((m) => m.modifierOptionName).join(', ')}
                                </div>
                              )}
                              {item.notes && (
                                <div className="text-[10px] text-amber-700 italic">&quot;{item.notes}&quot;</div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="pt-2 flex space-x-3">
                      {!isOut ? (
                        <button
                          onClick={() => handlePickUp(order.id)}
                          className="flex-1 py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md shadow-purple-600/20 flex items-center justify-center space-x-1.5 transition"
                        >
                          <Send className="w-4 h-4" />
                          <span>Ambil & Antar ke Meja</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleDelivered(order.id)}
                          className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center space-x-1.5 transition"
                        >
                          <CheckCheck className="w-4 h-4" />
                          <span>Tandai Sudah Sampai Meja</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
