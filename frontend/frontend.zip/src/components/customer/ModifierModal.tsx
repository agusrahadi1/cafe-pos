'use client';

import React, { useState, useEffect } from 'react';
import { Product, ProductVariant, ModifierOption } from '@/types';
import { useCart, SelectedModifier } from '@/context/CartContext';
import { formatRupiah, getImageUrl } from '@/lib/utils';
import { X, Plus, Minus, Check } from 'lucide-react';

interface ModifierModalProps {
  product: Product | null;
  onClose: () => void;
}

export default function ModifierModal({ product, onClose }: ModifierModalProps) {
  const { addItem } = useCart();

  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | undefined>(undefined);
  const [selectedModifiers, setSelectedModifiers] = useState<SelectedModifier[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (product) {
      // Pre-select first variant if available
      if (product.variants && product.variants.length > 0) {
        setSelectedVariant(product.variants[0]);
      } else {
        setSelectedVariant(undefined);
      }
      setSelectedModifiers([]);
      setQuantity(1);
      setNotes('');
      setValidationError(null);
    }
  }, [product]);

  if (!product) return null;

  const handleModifierToggle = (
    group: { id: string; name: string; minSelect: number; maxSelect: number },
    option: ModifierOption
  ) => {
    const isSingleSelect = group.maxSelect === 1;

    setSelectedModifiers((prev) => {
      const isAlreadySelected = prev.some((m) => m.modifierOptionId === option.id);

      if (isSingleSelect) {
        // Filter out other options from this group
        const withoutGroup = prev.filter((m) => m.modifierGroupId !== group.id);
        if (isAlreadySelected) {
          // If required (minSelect >= 1), do not deselect
          if (group.minSelect >= 1) return prev;
          return withoutGroup;
        }
        return [
          ...withoutGroup,
          {
            modifierGroupId: group.id,
            modifierGroupName: group.name,
            modifierOptionId: option.id,
            modifierOptionName: option.name,
            price: Number(option.price),
          },
        ];
      } else {
        // Multi-select
        if (isAlreadySelected) {
          return prev.filter((m) => m.modifierOptionId !== option.id);
        } else {
          // Check maxSelect limit
          const currentGroupCount = prev.filter((m) => m.modifierGroupId === group.id).length;
          if (currentGroupCount >= group.maxSelect) {
            return prev;
          }
          return [
            ...prev,
            {
              modifierGroupId: group.id,
              modifierGroupName: group.name,
              modifierOptionId: option.id,
              modifierOptionName: option.name,
              price: Number(option.price),
            },
          ];
        }
      }
    });
  };

  const currentBasePrice = selectedVariant ? Number(selectedVariant.price) : Number(product.basePrice);
  const modifiersPrice = selectedModifiers.reduce((sum, m) => sum + m.price, 0);
  const unitPrice = currentBasePrice + modifiersPrice;
  const totalPrice = unitPrice * quantity;

  const handleAddToCart = () => {
    // Validate required modifier groups
    if (product.modifiers) {
      for (const group of product.modifiers) {
        if (group.isRequired || group.minSelect > 0) {
          const selectedInGroup = selectedModifiers.filter((m) => m.modifierGroupId === group.id);
          if (selectedInGroup.length < group.minSelect) {
            setValidationError(`Silakan pilih opsi untuk "${group.name}" (minimal ${group.minSelect})`);
            return;
          }
        }
      }
    }

    addItem(product, selectedVariant, selectedModifiers, quantity, notes);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            {product.image && (
              <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-100 shrink-0 overflow-hidden">
                <img
                  src={getImageUrl(product.image)}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="min-w-0">
              <h3 className="font-bold text-gray-900 text-lg truncate">{product.name}</h3>
              <p className="text-xs text-gray-500 line-clamp-1">{product.description || 'Pilih kustomisasi pesanan Anda'}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition shrink-0 ml-2"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1">
          {validationError && (
            <div className="p-3 bg-red-50 text-red-700 text-xs font-medium rounded-xl border border-red-100">
              {validationError}
            </div>
          )}

          {/* Variants Section */}
          {product.variants && product.variants.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-gray-900 uppercase tracking-wider mb-2">
                Pilih Varian
              </label>
              <div className="grid grid-cols-2 gap-2">
                {product.variants.map((variant) => {
                  const isSelected = selectedVariant?.id === variant.id;
                  return (
                    <button
                      key={variant.id}
                      type="button"
                      onClick={() => setSelectedVariant(variant)}
                      className={`p-3 rounded-xl border text-left flex justify-between items-center transition ${
                        isSelected
                          ? 'border-amber-600 bg-amber-50/60 text-amber-900 font-semibold'
                          : 'border-gray-200 hover:border-gray-300 text-gray-700'
                      }`}
                    >
                      <span className="text-sm">{variant.name}</span>
                      <span className="text-xs text-gray-500">{formatRupiah(variant.price)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Modifier Groups Section */}
          {product.modifiers &&
            product.modifiers.map((group) => (
              <div key={group.id} className="space-y-2">
                <div className="flex justify-between items-baseline">
                  <label className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                    {group.name}
                  </label>
                  <span className="text-[11px] text-gray-500">
                    {group.isRequired ? (
                      <span className="text-red-500 font-semibold">Wajib • </span>
                    ) : (
                      'Opsional • '
                    )}
                    {group.maxSelect === 1 ? 'Pilih 1' : `Maks ${group.maxSelect}`}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {group.options.map((option) => {
                    const isSelected = selectedModifiers.some((m) => m.modifierOptionId === option.id);
                    const optPrice = Number(option.price);

                    return (
                      <button
                        key={option.id}
                        type="button"
                        onClick={() => handleModifierToggle(group, option)}
                        className={`w-full p-2.5 rounded-xl border text-left flex justify-between items-center transition ${
                          isSelected
                            ? 'border-amber-600 bg-amber-50/50 text-amber-950 font-medium'
                            : 'border-gray-100 hover:border-gray-200 text-gray-700'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <div
                            className={`w-4 h-4 ${
                              group.maxSelect === 1 ? 'rounded-full' : 'rounded-md'
                            } border flex items-center justify-center transition-colors ${
                              isSelected
                                ? 'bg-amber-600 border-amber-600 text-white shadow-xs'
                                : 'border-stone-300 bg-white'
                            }`}
                          >
                            {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                          </div>
                          <span className="text-sm">{option.name}</span>
                        </div>

                        {optPrice > 0 && (
                          <span className="text-xs text-amber-700 font-medium">
                            +{formatRupiah(optPrice)}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}

          {/* Special Instructions */}
          <div>
            <label className="block text-xs font-bold text-gray-900 uppercase tracking-wider mb-1.5">
              Catatan Khusus (Opsional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Jangan terlalu manis, es dipisah, dll."
              rows={2}
              className="w-full text-sm p-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 transition resize-none"
            />
          </div>
        </div>

        {/* Bottom Bar: Quantity & Add Button */}
        <div className="p-4 border-t border-gray-100 bg-gray-50/80 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center border border-gray-300 rounded-xl bg-white p-1">
            <button
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              disabled={quantity <= 1}
              className="w-8 h-8 flex items-center justify-center rounded-lg text-gray-600 hover:bg-gray-100 disabled:opacity-30 transition"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="w-8 text-center text-sm font-bold text-gray-900">{quantity}</span>
            <button
              onClick={() => setQuantity((q) => q + 1)}
              className="w-8 h-8 flex items-center justify-center rounded-lg text-gray-600 hover:bg-gray-100 transition"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={handleAddToCart}
            className="flex-1 py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold text-sm shadow-md shadow-amber-600/20 flex items-center justify-between transition"
          >
            <span>Tambah</span>
            <span className="font-bold">{formatRupiah(totalPrice)}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

