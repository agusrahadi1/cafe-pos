/* eslint-disable @next/next/no-img-element */
'use client';

import React, { useState } from 'react';
import { useCart } from '@/context/CartContext';
import { formatRupiah, getImageUrl } from '@/lib/utils';
import { api } from '@/lib/api';
import { useRouter } from 'next/navigation';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  CreditCard,
  Banknote,
  Loader2,
  AlertCircle,
  QrCode as QrIcon,
  Zap,
  ShieldCheck,
} from 'lucide-react';
import { PaymentMethod } from '@/types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  company?: any;
  tableToken?: string;
}

export default function CartDrawer({ isOpen, onClose, company, tableToken }: CartDrawerProps) {
  const router = useRouter();
  const {
    items,
    tableId,
    tableNumber,
    customerName,
    customerPhone,
    customerNotes,
    subtotal,
    taxAmount,
    serviceChargeAmount,
    totalAmount,
    setCustomerInfo,
    updateQuantity,
    removeItem,
    clearCart,
  } = useCart();

  const [name, setName] = useState(customerName || '');
  const [phone, setPhone] = useState(customerPhone || '');
  const [notes, setNotes] = useState(customerNotes || '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('XENDIT');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmitOrder = async () => {
    if (!name.trim()) {
      setError('Mohon masukkan nama pemesan.');
      return;
    }

    if (items.length === 0) {
      setError('Keranjang Anda masih kosong.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      setCustomerInfo(name, phone, notes);

      // Build payload according to CreateOrderDto
      const payload = {
        tableId: tableId || undefined,
        customerName: name.trim(),
        customerPhone: phone.trim() || undefined,
        customerNotes: notes.trim() || undefined,
        paymentMethod,
        items: items.map((item) => ({
          productId: item.product.id,
          variantId: item.variant?.id || undefined,
          quantity: item.quantity,
          notes: item.notes || undefined,
          modifiers: item.selectedModifiers.map((m) => ({
            modifierGroupId: m.modifierGroupId,
            modifierOptionId: m.modifierOptionId,
          })),
        })),
      };

      const order = await api.post<any>('/orders', payload);

      if (order && order.id) {
        // If payment method is XENDIT or QRIS, create Xendit invoice and redirect
        if (paymentMethod === 'XENDIT' || paymentMethod === 'QRIS') {
          try {
            const xenditRes = await api.post<any>('/payments/xendit/invoice', { orderId: order.id });
            if (xenditRes && xenditRes.invoiceUrl) {
              clearCart();
              onClose();
              window.location.href = xenditRes.invoiceUrl;
              return;
            }
          } catch (xerr: any) {
            console.error('Gagal generate invoice Xendit:', xerr);
            // Fallback to order status page if invoice creation fails
          }
        }

        if (typeof window !== 'undefined' && tableToken) {
          localStorage.setItem('cafe_active_qr_token', tableToken);
          if (tableNumber) localStorage.setItem('cafe_active_table_number', String(tableNumber));
        }

        clearCart();
        onClose();
        const tokenQuery = tableToken ? `?token=${encodeURIComponent(tableToken)}` : '';
        router.push(`/order/status/${order.id}${tokenQuery}`);
      } else {
        setError('Gagal membuat pesanan. Silakan coba lagi.');
      }
    } catch (err: any) {
      setError(err.message || 'Gagal mengirim pesanan.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center space-x-2.5">
            {company?.logoUrl || company?.logo ? (
              <img
                src={getImageUrl(company.logoUrl || company.logo)}
                alt={company?.name || 'Logo'}
                className="w-9 h-9 object-contain rounded-xl bg-amber-50 p-1 border border-amber-200 shrink-0"
              />
            ) : (
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                <ShoppingBag className="w-4 h-4" />
              </div>
            )}
            <div>
              <h3 className="font-bold text-gray-900 text-sm leading-tight">
                {company?.name ? company.name : 'Keranjang Pesanan'}
              </h3>
              <div className="text-xs font-semibold text-amber-700 flex items-center space-x-1 mt-0.5">
                {tableNumber ? (
                  <span>Pesanan Meja {tableNumber}</span>
                ) : (
                  <span>Pesanan Baru</span>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {error && (
            <div className="p-3 bg-red-50 text-red-700 text-xs font-medium rounded-xl border border-red-100 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Items List */}
          {items.length === 0 ? (
            <div className="py-12 text-center text-gray-400">
              <ShoppingBag className="w-12 h-12 mx-auto mb-2 opacity-30 stroke-1" />
              <p className="text-sm font-medium">Keranjang belanja kosong</p>
              <p className="text-xs text-gray-400 mt-1">Pilih menu favorit Anda terlebih dahulu</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-bold text-gray-500 uppercase tracking-wider">
                <span>Item Pesanan ({items.reduce((s, i) => s + i.quantity, 0)})</span>
                <button
                  onClick={clearCart}
                  className="text-red-500 hover:text-red-700 font-normal transition"
                >
                  Hapus Semua
                </button>
              </div>

              {items.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 bg-gray-50/80 rounded-xl border border-gray-100 flex flex-col space-y-2"
                >
                  <div className="flex justify-between items-start">
                    <div className="pr-2">
                      <div className="font-bold text-sm text-gray-900">{item.product.name}</div>
                      {item.variant && (
                        <div className="text-xs text-amber-800 font-medium">
                          Varian: {item.variant.name}
                        </div>
                      )}
                      {item.selectedModifiers.length > 0 && (
                        <div className="text-[11px] text-gray-500 mt-0.5">
                          {item.selectedModifiers.map((m) => m.modifierOptionName).join(', ')}
                        </div>
                      )}
                      {item.notes && (
                        <div className="text-[11px] text-gray-500 italic mt-0.5">
                          &quot;{item.notes}&quot;
                        </div>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-bold text-sm text-gray-900">
                        {formatRupiah(item.totalPrice)}
                      </span>
                    </div>
                  </div>

                  {/* Quantity Actions */}
                  <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-gray-400 hover:text-red-500 transition p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center space-x-2 bg-white px-2 py-1 rounded-lg border border-gray-200">
                      <button
                        onClick={() => updateQuantity(item.id, -1)}
                        className="text-gray-600 hover:text-amber-600 p-0.5"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-gray-900 w-4 text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, 1)}
                        className="text-gray-600 hover:text-amber-600 p-0.5"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Customer Details Form */}
          {items.length > 0 && (
            <div className="space-y-3 pt-2 border-t border-gray-100">
              <label className="block text-xs font-bold text-gray-900 uppercase tracking-wider">
                Informasi Pemesan
              </label>

              <div>
                <input
                  type="text"
                  placeholder="Nama Lengkap *"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full text-sm p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
                />
              </div>

              <div>
                <input
                  type="tel"
                  placeholder="Nomor WhatsApp (Opsional)"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-sm p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Catatan pesanan meja (Opsional)"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-sm p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
                />
              </div>
            </div>
          )}

          {/* Payment Method Selector */}
          {items.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-gray-100">
              <label className="block text-xs font-bold text-gray-900 uppercase tracking-wider">
                Metode Pembayaran
              </label>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('XENDIT')}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition relative overflow-hidden ${
                    paymentMethod === 'XENDIT'
                      ? 'border-amber-600 bg-amber-50/80 text-amber-900 font-semibold ring-2 ring-amber-500/20'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700 bg-white'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <QrIcon className="w-4 h-4 text-amber-600" />
                    <span className="text-xs font-bold">QRIS & Online</span>
                  </div>
                  <span className="text-[10px] text-gray-500 mt-1">Xendit • Auto Verifikasi</span>
                  <div className="mt-1.5 flex items-center gap-1 text-[9px] font-semibold text-emerald-700 bg-emerald-100/80 px-1.5 py-0.5 rounded w-fit">
                    <Zap className="w-2.5 h-2.5" />
                    <span>Instan Otomatis</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('CASH')}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition ${
                    paymentMethod === 'CASH'
                      ? 'border-amber-600 bg-amber-50/80 text-amber-900 font-semibold ring-2 ring-amber-500/20'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700 bg-white'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Banknote className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-bold">Bayar Kasir</span>
                  </div>
                  <span className="text-[10px] text-gray-500 mt-1">Bayar tunai di kasir</span>
                  <div className="mt-1.5 flex items-center gap-1 text-[9px] font-medium text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded w-fit">
                    <span>Kasir Manual</span>
                  </div>
                </button>
              </div>

              {/* Xendit Payment Banner Info */}
              {paymentMethod === 'XENDIT' && (
                <div className="p-3.5 bg-gradient-to-br from-amber-50/90 to-orange-50/60 border border-amber-200 rounded-2xl space-y-2 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-amber-700" />
                      <span>Pembayaran Otomatis</span>
                    </span>
                    <span className="text-[10px] font-bold bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded-full">
                      Otomatis
                    </span>
                  </div>
                  <p className="text-[11px] text-gray-600 leading-relaxed">
                    Mendukung pembayaran langsung dengan <strong>QRIS (Semua Bank & E-Wallet)</strong>, GoPay, OVO, DANA, ShopeePay, serta Virtual Account BCA, Mandiri, BRI, BNI.
                  </p>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {['QRIS Dinamis', 'GoPay', 'OVO', 'DANA', 'ShopeePay', 'BCA VA', 'Mandiri VA', 'BRI VA'].map((channel) => (
                      <span
                        key={channel}
                        className="text-[10px] font-semibold bg-white border border-amber-200/80 text-gray-700 px-2 py-0.5 rounded-md shadow-2xs"
                      >
                        {channel}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {paymentMethod === 'CASH' && (
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 text-xs text-gray-600 space-y-1">
                  <div className="font-semibold text-gray-800 flex items-center gap-1.5">
                    <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Pembayaran Tunai di Kasir</span>
                  </div>
                  <p className="text-[11px] text-gray-500">
                    Setelah memesan, silakan menuju kasir dan sebutkan nomor pesanan untuk bayar tunai.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Price Breakdown */}
          {items.length > 0 && (
            <div className="p-3.5 bg-gray-50 rounded-xl space-y-2 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-gray-900">{formatRupiah(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Pajak Resto (10%)</span>
                <span>{formatRupiah(taxAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span>Service Charge (5%)</span>
                <span>{formatRupiah(serviceChargeAmount)}</span>
              </div>
              <div className="pt-2 border-t border-gray-200 flex justify-between font-bold text-sm text-gray-900">
                <span>Total Pembayaran</span>
                <span className="text-amber-700 text-base">{formatRupiah(totalAmount)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Checkout Button */}
        {items.length > 0 && (
          <div className="p-4 border-t border-gray-100 bg-white shrink-0">
            <button
              onClick={handleSubmitOrder}
              disabled={loading}
              className="w-full py-3.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm shadow-lg shadow-amber-600/30 flex items-center justify-center space-x-2 disabled:opacity-50 transition"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  <span>Memproses Pesanan...</span>
                </>
              ) : (
                <span>Kirim Pesanan Sekarang • {formatRupiah(totalAmount)}</span>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

